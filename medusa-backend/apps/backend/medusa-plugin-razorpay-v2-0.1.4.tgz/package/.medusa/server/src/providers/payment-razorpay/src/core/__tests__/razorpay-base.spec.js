"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const globals_1 = require("@jest/globals");
const utils_1 = require("@medusajs/framework/utils");
const dotenv_1 = __importDefault(require("dotenv"));
const types_1 = require("../../types");
const data_1 = require("../__fixtures__/data");
const razorpay_test_1 = require("../__fixtures__/razorpay-test");
const razorpay_1 = require("../__mocks__/razorpay");
let config = {
    key_id: "test",
    key_secret: "test",
    razorpay_account: "test",
    automatic_expiry_period: 30,
    manual_expiry_period: 20,
    refund_speed: "normal",
    webhook_secret: "test",
    auto_capture: false
};
if (!(0, razorpay_1.isMocksEnabled)()) {
    dotenv_1.default.config();
}
const container = {
    logger: {
        error: console.error,
        info: console.info,
        warn: console.warn,
        debug: console.log
    },
    cartService: {
        retrieve() {
            return {
                id: "test-cart",
                billing_address: { phone: "12345" }
            };
        }
    },
    customerService: {
        retrieve: (id) => {
            return {
                id
            };
        },
        update: (id, data) => {
            const customer = {
                id,
                ...data
            };
            return customer;
        }
    }
};
config = {
    ...config,
    key_id: process.env.RAZORPAY_ID,
    key_secret: process.env.RAZORPAY_SECRET,
    razorpay_account: process.env.RAZORPAY_ACCOUNT
};
let testPaymentSession;
let razorpayTest;
(0, globals_1.describe)("RazorpayTest", () => {
    (0, globals_1.describe)("getPaymentStatus", () => {
        (0, globals_1.beforeAll)(async () => {
            if (!(0, razorpay_1.isMocksEnabled)()) {
                globals_1.jest.requireActual("razorpay");
            }
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        if ((0, razorpay_1.isMocksEnabled)()) {
            (0, globals_1.it)("should return the correct status", async () => {
                let status;
                status = await razorpayTest.getPaymentStatus({
                    data: { id: data_1.PaymentIntentDataByStatus.CREATED.id }
                });
                (0, globals_1.expect)(status.status).toBe(utils_1.PaymentSessionStatus.PENDING);
                status = await razorpayTest.getPaymentStatus({
                    data: { id: data_1.PaymentIntentDataByStatus.CREATED.id }
                });
                (0, globals_1.expect)(status.status).toBe(utils_1.PaymentSessionStatus.PENDING);
                (0, globals_1.expect)(status.status).toBe(utils_1.PaymentSessionStatus.PENDING);
                status = await razorpayTest.getPaymentStatus({
                    data: { id: data_1.PaymentIntentDataByStatus.ATTEMPTED.id }
                });
                (0, globals_1.expect)(status.status).toBe(utils_1.PaymentSessionStatus.AUTHORIZED);
                status = await razorpayTest.getPaymentStatus({
                    data: { id: "unknown-id" }
                });
                (0, globals_1.expect)(status).toBe(utils_1.PaymentSessionStatus.PENDING);
            });
        }
        else {
            (0, globals_1.it)("should return the correct status", async () => {
                const result = await razorpayTest.initiatePayment(data_1.initiatePaymentContextWithExistingCustomer);
                const status = await razorpayTest.getPaymentStatus(result);
                (0, globals_1.expect)(status.status).toBe(utils_1.PaymentSessionStatus.REQUIRES_MORE);
            });
        }
    });
    (0, globals_1.describe)("initiatePayment", () => {
        let razorpayTest;
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should succeed with an existing customer but no razorpay id", async () => {
            const result = await razorpayTest.initiatePayment(data_1.initiatePaymentContextWithExistingCustomer);
            if ((0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.expect)(razorpay_1.RazorpayMock.orders.create).toHaveBeenCalled();
                /* expect(RazorpayMock.customers.create).toHaveBeenCalledWith({
        email: initiatePaymentContextWithExistingCustomer.email,
        name: "test, customer",
      });*/
                (0, globals_1.expect)(razorpay_1.RazorpayMock.orders.create).toHaveBeenCalled();
                /* expect(RazorpayMock.orders.create).toHaveBeenCalledWith(
          expect.objectContaining({
            description: undefined,
            amount: initiatePaymentContextWithExistingCustomer.amount,
            currency: initiatePaymentContextWithExistingCustomer.currency_code,
            notes: {
              resource_id:
                initiatePaymentContextWithExistingCustomer.resource_id,
            },
            capture_method: "manual",
          })
        );*/
            }
            (0, globals_1.expect)(result).toEqual(globals_1.expect.objectContaining({
                session_data: globals_1.expect.any(Object),
                update_requests: {
                    customer_metadata: {
                        razorpay_id: (0, razorpay_1.isMocksEnabled)()
                            ? razorpay_1.RAZORPAY_ID
                            : globals_1.expect.stringContaining("cus")
                    }
                }
            }));
        });
        (0, globals_1.it)("should succeed with an existing customer with an existing razorpay id", async () => {
            const result = await razorpayTest.initiatePayment(data_1.initiatePaymentContextWithExistingCustomerRazorpayId);
            if ((0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.expect)(razorpay_1.RazorpayMock.customers.create).not.toHaveBeenCalled();
                (0, globals_1.expect)(razorpay_1.RazorpayMock.orders.create).toHaveBeenCalled();
                /* expect(RazorpayMock.orders.create).toMatchObject({
          description: undefined,
          amount: initiatePaymentContextWithExistingCustomer.amount,
          currency: initiatePaymentContextWithExistingCustomer.currency_code,
          notes: {
            resource_id: initiatePaymentContextWithExistingCustomer.resource_id,
          },
          capture_method: "manual",
        });*/
            }
            (0, globals_1.expect)(result).toMatchObject(!(0, razorpay_1.isMocksEnabled)()
                ? {
                    session_data: globals_1.expect.any(Object),
                    update_requests: globals_1.expect.any(Object)
                }
                : {
                    session_data: globals_1.expect.any(Object)
                });
            if (!(0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.expect)(result.id).toBeDefined();
            }
        });
        /* it("should fail on customer creation", async () => {
      /const result = await razorpayTest.initiatePayment(
        initiatePaymentContextWithWrongEmail as any
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.customers.create).toHaveBeenCalled();
        expect(RazorpayMock.customers.create).toHaveBeenCalledWith({
          email: initiatePaymentContextWithWrongEmail.email,
        });

        expect(RazorpayMock.orders.create).not.toHaveBeenCalled();
      }
      expect(result).toEqual({
        error:
          "An error occurred in initiatePayment when creating a Razorpay customer",
        code: "",
        detail: "Error",
      });
    });*/
        /* it("should fail on payment intents creation", async () => {
      const result = await razorpayTest.initiatePayment(
        initiatePaymentContextWithFailIntentCreation as any
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.customers.create).toHaveBeenCalled();
        expect(RazorpayMock.customers.create).toHaveBeenCalledWith({
          email: initiatePaymentContextWithFailIntentCreation.email,
        });

        expect(RazorpayMock.orders.create).toHaveBeenCalled();
        expect(RazorpayMock.orders.create).toHaveBeenCalledWith(
          expect.objectContaining({
            description:
              initiatePaymentContextWithFailIntentCreation.context
                .payment_description,
            amount: initiatePaymentContextWithFailIntentCreation.amount,
            currency:
              initiatePaymentContextWithFailIntentCreation.currency_code,
            notes: {
              resource_id:
                initiatePaymentContextWithFailIntentCreation.resource_id,
            },
            capture_method: "manual",
          })
        );
      }

      expect(result).toEqual({
        error:
          "An error occurred in InitiatePayment during the creation of the razorpay payment intent",
        code: "",
        detail: "Error",
      });
    });*/
    });
    (0, globals_1.describe)("authorizePayment", () => {
        let razorpayTest;
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should succeed", async () => {
            if (!(0, razorpay_1.isMocksEnabled)()) {
                testPaymentSession = await razorpayTest.initiatePayment(data_1.initiatePaymentContextWithExistingCustomer);
            }
            const result = await razorpayTest.authorizePayment((0, razorpay_1.isMocksEnabled)()
                ? data_1.authorizePaymentSuccessData
                : {
                    data: testPaymentSession?.data
                });
            (0, globals_1.expect)(result).toMatchObject({
                data: (0, razorpay_1.isMocksEnabled)()
                    ? data_1.authorizePaymentSuccessData
                    : {
                        id: globals_1.expect.stringContaining("order_")
                    },
                status: (0, razorpay_1.isMocksEnabled)()
                    ? utils_1.PaymentSessionStatus.AUTHORIZED
                    : utils_1.PaymentSessionStatus.REQUIRES_MORE
            });
        });
    });
    (0, globals_1.describe)("cancelPayment", () => {
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should succeed", async () => {
            const result = await razorpayTest.cancelPayment({
                data: data_1.cancelPaymentSuccessData
            });
            (0, globals_1.expect)(result).toEqual({
                code: types_1.ErrorCodes.UNSUPPORTED_OPERATION,
                error: "Unable to cancel as razorpay doesn't support cancellation"
            });
        });
        (0, globals_1.it)("should fail on intent cancellation but still return the intent", async () => {
            const result = await razorpayTest.cancelPayment({
                data: data_1.cancelPaymentPartiallyFailData
            });
            (0, globals_1.expect)(result).toEqual({
                code: types_1.ErrorCodes.UNSUPPORTED_OPERATION,
                error: "Unable to cancel as razorpay doesn't support cancellation"
            });
        });
        (0, globals_1.it)("should fail on intent cancellation", async () => {
            const result = await razorpayTest.cancelPayment({
                data: data_1.cancelPaymentFailData
            });
            /* expect(result).toEqual({
        error: "An error occurred in cancelPayment",
        code: "",
        detail: "Error",
      });*/
            (0, globals_1.expect)(result).toEqual({
                code: types_1.ErrorCodes.UNSUPPORTED_OPERATION,
                error: "Unable to cancel as razorpay doesn't support cancellation"
            });
        });
    });
    (0, globals_1.describe)("capturePayment", () => {
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should succeed", async () => {
            const result = await razorpayTest.capturePayment((0, razorpay_1.isMocksEnabled)()
                ? data_1.capturePaymentContextSuccessData.paymentSessionData
                : {
                    data: testPaymentSession?.data
                });
            if ((0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.expect)(result).toEqual({
                    id: data_1.PaymentIntentDataByStatus.ATTEMPTED.id
                });
            }
            else {
                (0, globals_1.expect)(result).toMatchObject({
                    payments: globals_1.expect.any(Object)
                });
            }
        });
        /* it("should fail on intent capture but still return the intent", async () => {
      const result = await razorpayTest.capturePayment(
        capturePaymentContextPartiallyFailData.paymentSessionData
      );

      expect(result).toEqual({
        id: PARTIALLY_FAIL_INTENT_ID,
        status: ErrorIntentStatus.SUCCEEDED,
      });
    });

    it("should fail on intent capture", async () => {
      const result = await razorpayTest.capturePayment(
        capturePaymentContextFailData.paymentSessionData
      );

      expect(result).toEqual({
        error: "An error occurred in capturePayment",
        code: "",
        detail: "Error",
      });
    });*/
    });
    (0, globals_1.describe)("deletePayment", () => {
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should succeed", async () => {
            const result = await razorpayTest.cancelPayment({
                data: data_1.deletePaymentSuccessData
            });
            (0, globals_1.expect)(result).toEqual({
                code: "payment_intent_operation_unsupported",
                error: "Unable to cancel as razorpay doesn't support cancellation"
            });
        });
        (0, globals_1.it)("should fail on intent cancellation but still return the intent", async () => {
            const result = await razorpayTest.cancelPayment({
                data: data_1.deletePaymentPartiallyFailData
            });
            (0, globals_1.expect)(result).toEqual({
                code: "payment_intent_operation_unsupported",
                error: "Unable to cancel as razorpay doesn't support cancellation"
            });
        });
        (0, globals_1.it)("should fail on intent cancellation", async () => {
            const result = await razorpayTest.cancelPayment({
                data: data_1.deletePaymentFailData
            });
            (0, globals_1.expect)(result).toEqual({
                code: "payment_intent_operation_unsupported",
                error: "Unable to cancel as razorpay doesn't support cancellation"
            });
        });
    });
    (0, globals_1.describe)("refundPayment", () => {
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should succeed", async () => {
            const result = await razorpayTest.refundPayment((0, razorpay_1.isMocksEnabled)()
                ? {
                    data: data_1.refundPaymentSuccessData,
                    amount: 500
                }
                : {
                    data: testPaymentSession?.data,
                    amount: 500
                });
            if ((0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.expect)(result).toMatchObject({
                    sessionid: data_1.PaymentIntentDataByStatus.ATTEMPTED.id
                });
            }
            else {
                (0, globals_1.expect)(result).toMatchObject({
                    payments: globals_1.expect.any(Object)
                });
            }
        });
        /* it("should fail on refund creation", async () => {
      const result = await razorpayTest.refundPayment(
        isMocksEnabled() ? refundPaymentFailData : testPaymentSession,
        refundAmount
      );

      expect(result).toEqual({
        error: "An error occurred in refundPayment",
        code: "",
        detail: "Error",
      });
    }); */
    });
    (0, globals_1.describe)("retrievePayment", () => {
        (0, globals_1.beforeAll)(async () => {
            const scopedContainer = { ...container };
            razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
        });
        (0, globals_1.beforeEach)(() => {
            globals_1.jest.clearAllMocks();
        });
        (0, globals_1.it)("should retrieve", async () => {
            const result = await razorpayTest.retrievePayment((0, razorpay_1.isMocksEnabled)()
                ? data_1.retrievePaymentSuccessData
                : {
                    data: testPaymentSession?.data
                });
            if ((0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.expect)(result).toMatchObject({
                    status: "attempted"
                });
            }
            else {
                const retrieveResult = result;
                (0, globals_1.expect)(retrieveResult.data?.id).toBeDefined();
                (0, globals_1.expect)(retrieveResult.data?.id).toMatch("order_");
            }
        });
        /* it("should fail on refund creation", async () => {
      const result = await razorpayTest.retrievePayment(
        retrievePaymentFailData
      );

      expect(result).toEqual({
        error: "An error occurred in retrievePayment",
        code: "",
        detail: "Error",
      });
    });*/
    });
    if (!(0, razorpay_1.isMocksEnabled)()) {
        (0, globals_1.describe)("updatePayment", () => {
            if (!(0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.beforeAll)(async () => {
                    const scopedContainer = { ...container };
                    razorpayTest = new razorpay_test_1.RazorpayTest(scopedContainer, config);
                });
                (0, globals_1.beforeEach)(() => {
                    globals_1.jest.clearAllMocks();
                });
            }
            /* it("should succeed to initiate a payment with an existing customer but no razorpay id", async () => {
      const paymentContext: PaymentProcessorContext = {
        email: updatePaymentContextWithDifferentAmount.email,
        currency_code: updatePaymentContextWithDifferentAmount.currency_code,
        amount: updatePaymentContextWithDifferentAmount.amount,
        resource_id: updatePaymentContextWithDifferentAmount.resource_id,
        context: updatePaymentContextWithDifferentAmount.context,
        paymentSessionData: testPaymentSession.session_data,
      };
      const result = await razorpayTest.updatePayment(
        updatePaymentContextWithExistingCustomer as any
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.customers.create).toHaveBeenCalled();
        expect(RazorpayMock.customers.create).toHaveBeenCalledWith({
          email: updatePaymentContextWithExistingCustomer.email,
        });

        expect(RazorpayMock.orders.create).toHaveBeenCalled();
        expect(RazorpayMock.orders.create).toHaveBeenCalledWith(
          expect.objectContaining({
            description: undefined,
            amount: updatePaymentContextWithExistingCustomer.amount,
            currency: updatePaymentContextWithExistingCustomer.currency_code,
            notes: {
              resource_id: updatePaymentContextWithExistingCustomer.resource_id,
            },
            capture_method: "manual",
          })
        );
      }

      expect(result).toMatchObject({
        session_data: { id: expect.stringMatching("order") },
        update_requests: {
          customer_metadata: {
            razorpay_id: isMocksEnabled()
              ? RAZORPAY_ID
              : expect.stringMatching("cus"),
          },
        },
      });
    }, 60e6); */
            /* it("should fail to initiate a payment with an existing customer but no razorpay id", async () => {
      const result = await razorpayTest.updatePayment(
        updatePaymentContextWithWrongEmail
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.customers.create).toHaveBeenCalled();
        expect(RazorpayMock.customers.create).toHaveBeenCalledWith({
          email: updatePaymentContextWithWrongEmail.email,
        });

        expect(RazorpayMock.orders.create).not.toHaveBeenCalled();
      }
      expect(result).toEqual({
        error:
          "An error occurred in updatePayment during the initiate of the new payment for the new customer",
        code: "",
        detail:
          "An error occurred in initiatePayment when creating a Razorpay customer" +
          EOL +
          "Error",
      });
    });

    it("should succeed but no update occurs when the amount did not changed", async () => {
      const result = await razorpayTest.updatePayment(
        updatePaymentContextWithExistingCustomerRazorpayId
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.orders.edit).not.toHaveBeenCalled();
      }
      expect(result).not.toBeDefined();
    });
    */
            if (!(0, razorpay_1.isMocksEnabled)()) {
                (0, globals_1.it)("should succeed to update the intent with the new amount", async () => {
                    const paymentContext = {
                        currency_code: data_1.updatePaymentContextWithDifferentAmount.currency_code,
                        amount: data_1.updatePaymentContextWithDifferentAmount.amount,
                        context: {
                            customer: {
                                email: data_1.updatePaymentContextWithDifferentAmount.email,
                                id: data_1.updatePaymentContextWithDifferentAmount.customer_id
                            }
                            // extra: {
                            //     resource_id:
                            //         updatePaymentContextWithDifferentAmount.resource_id,
                            //     context:
                            //         updatePaymentContextWithDifferentAmount.context,
                            //     paymentSessionData: isMocksEnabled()
                            //         ? updatePaymentContextWithDifferentAmount.paymentSessionData
                            //         : testPaymentSession.session_data
                            // }
                        }
                    };
                    const result = await razorpayTest.updatePayment((0, razorpay_1.isMocksEnabled)()
                        ? data_1.updatePaymentContextWithDifferentAmount
                        : paymentContext);
                    if ((0, razorpay_1.isMocksEnabled)()) {
                        (0, globals_1.expect)(1).toBe(1);
                        console.log("test not valid in mocked mode");
                        // expect(RazorpayMock.orders.edit).toHaveBeenCalled();
                        /* expect(RazorpayMock.orders.edit).toHaveBeenCalledWith(
          updatePaymentContextWithDifferentAmount.paymentSessionData.id,
          {
            amount: updatePaymentContextWithDifferentAmount.amount,
          }
        );*/
                    }
                    (0, globals_1.expect)(result).toMatchObject({
                        session_data: {
                            amount: data_1.updatePaymentContextWithDifferentAmount.amount
                        }
                    });
                }, 60e6);
            }
            /* it("should fail to update the intent with the new amount", async () => {
      const result = await razorpayTest.updatePayment(
        updatePaymentContextFailWithDifferentAmount
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.orders.edit).toHaveBeenCalled();
        expect(RazorpayMock.orders.edit).toHaveBeenCalledWith(
          updatePaymentContextFailWithDifferentAmount.paymentSessionData.id,
          {
            amount: updatePaymentContextFailWithDifferentAmount.amount,
          }
        );
      }
      expect(result).toEqual({
        error: "An error occurred in updatePayment",
        code: "",
        detail: "Error",
      });
    });*/
        });
    }
    // describe("updatePaymentData", function () {
    //     beforeAll(async () => {
    //         const scopedContainer = { ...container };
    //         razorpayTest = new RazorpayTest(scopedContainer, config);
    //     });
    //     beforeEach(() => {
    //         jest.clearAllMocks();
    //     });
    //     it("should fail to update the payment data", async () => {
    //         const data = isMocksEnabled()
    //             ? { data: updatePaymentDataWithoutAmountDataNoNotes }
    //             : { ...updatePaymentDataWithoutAmountDataNoNotes };
    //         await razorpayTest.updatePaymentData(
    //             isMocksEnabled()
    //                 ? updatePaymentDataWithoutAmountData.sessionId
    //                 : (testPaymentSession.id as any),
    //             {
    //                 ...data,
    //                 sessionId: isMocksEnabled()
    //                     ? undefined
    //                     : testPaymentSession.id
    //             }
    //         );
    //         if (isMocksEnabled()) {
    //             expect(RazorpayMock.orders.edit).toHaveBeenCalledTimes(0);
    //         }
    //     }, 60e6);
    //     it("should succeed to update the payment data", async () => {
    //         const data = isMocksEnabled()
    //             ? {
    //                   data: {
    //                       ...updatePaymentDataWithoutAmountData,
    //                       notes: { updated: true }
    //                   }
    //               }
    //             : { ...updatePaymentDataWithoutAmountData };
    //         await razorpayTest.updatePaymentData(
    //             isMocksEnabled()
    //                 ? updatePaymentDataWithoutAmountData.sessionId
    //                 : (testPaymentSession.id as any),
    //             {
    //                 ...data,
    //                 sessionId: isMocksEnabled()
    //                     ? undefined
    //                     : testPaymentSession.id
    //             }
    //         );
    //         if (isMocksEnabled()) {
    //             expect(RazorpayMock.orders.edit).toHaveBeenCalled();
    //         }
    //     }, 60e6);
    /* it("should fail to update the payment data if the amount is present", async () => {
      const result = await razorpayTest.updatePaymentData(
        updatePaymentDataWithAmountData.sessionId,
        { ...updatePaymentDataWithAmountData, sessionId: undefined }
      );
      if (isMocksEnabled()) {
        expect(RazorpayMock.orders.edit).not.toHaveBeenCalled();
      }
      expect(result).toEqual({
        error: "An error occurred in updatePaymentData",
        code: undefined,
        detail: "Cannot update amount, use updatePayment instead",
      });
    });*/
    //    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmF6b3JwYXktYmFzZS5zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vc3JjL3Byb3ZpZGVycy9wYXltZW50LXJhem9ycGF5L3NyYy9jb3JlL19fdGVzdHNfXy9yYXpvcnBheS1iYXNlLnNwZWMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSwyQ0FPdUI7QUFDdkIscURBQWlFO0FBZWpFLG9EQUE0QjtBQUM1Qix1Q0FBK0Q7QUFDL0QsK0NBZThCO0FBQzlCLGlFQUE2RDtBQUM3RCxvREFJK0I7QUFFL0IsSUFBSSxNQUFNLEdBQW9CO0lBQzFCLE1BQU0sRUFBRSxNQUFNO0lBQ2QsVUFBVSxFQUFFLE1BQU07SUFDbEIsZ0JBQWdCLEVBQUUsTUFBTTtJQUN4Qix1QkFBdUIsRUFBRSxFQUFFO0lBQzNCLG9CQUFvQixFQUFFLEVBQUU7SUFDeEIsWUFBWSxFQUFFLFFBQVE7SUFDdEIsY0FBYyxFQUFFLE1BQU07SUFDdEIsWUFBWSxFQUFFLEtBQUs7Q0FDdEIsQ0FBQztBQUNGLElBQUksQ0FBQyxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO0lBQ3BCLGdCQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7QUFDcEIsQ0FBQztBQUNELE1BQU0sU0FBUyxHQUFHO0lBQ2QsTUFBTSxFQUFFO1FBQ0osS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1FBQ3BCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtRQUNsQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7UUFDbEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxHQUFHO0tBQ3JCO0lBQ0QsV0FBVyxFQUFFO1FBQ1QsUUFBUTtZQUNKLE9BQU87Z0JBQ0gsRUFBRSxFQUFFLFdBQVc7Z0JBQ2YsZUFBZSxFQUFFLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRTthQUMzQixDQUFDO1FBQ2pCLENBQUM7S0FDSjtJQUNELGVBQWUsRUFBRTtRQUNiLFFBQVEsRUFBRSxDQUFDLEVBQVUsRUFBd0IsRUFBRTtZQUMzQyxPQUFPO2dCQUNILEVBQUU7YUFDTCxDQUFDO1FBQ04sQ0FBQztRQUNELE1BQU0sRUFBRSxDQUFDLEVBQVUsRUFBRSxJQUEwQixFQUFlLEVBQUU7WUFDNUQsTUFBTSxRQUFRLEdBQWdCO2dCQUMxQixFQUFFO2dCQUNGLEdBQUcsSUFBSTthQUNLLENBQUM7WUFDakIsT0FBTyxRQUFRLENBQUM7UUFDcEIsQ0FBQztLQUNKO0NBQ0osQ0FBQztBQUVGLE1BQU0sR0FBRztJQUNMLEdBQUcsTUFBTTtJQUNULE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVk7SUFDaEMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZ0I7SUFDeEMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBaUI7Q0FDbEQsQ0FBQztBQUNGLElBQUksa0JBQXFELENBQUM7QUFDMUQsSUFBSSxZQUEwQixDQUFDO0FBQy9CLElBQUEsa0JBQVEsRUFBQyxjQUFjLEVBQUUsR0FBRyxFQUFFO0lBQzFCLElBQUEsa0JBQVEsRUFBQyxrQkFBa0IsRUFBRSxHQUFHLEVBQUU7UUFDOUIsSUFBQSxtQkFBUyxFQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO2dCQUNwQixjQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ25DLENBQUM7WUFFQyxNQUFNLGVBQWUsR0FBRyxFQUFFLEdBQUcsU0FBUyxFQUFnQyxDQUFDO1lBQ3pFLFlBQVksR0FBRyxJQUFJLDRCQUFZLENBQUMsZUFBa0MsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNoRixDQUFDLENBQUMsQ0FBQztRQUVILElBQUEsb0JBQVUsRUFBQyxHQUFHLEVBQUU7WUFDWixjQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLElBQUEseUJBQWMsR0FBRSxFQUFFLENBQUM7WUFDbkIsSUFBQSxZQUFFLEVBQUMsa0NBQWtDLEVBQUUsS0FBSyxJQUFJLEVBQUU7Z0JBQzlDLElBQUksTUFBOEIsQ0FBQztnQkFFbkMsTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGdCQUFnQixDQUFDO29CQUN6QyxJQUFJLEVBQUUsRUFBRSxFQUFFLEVBQUUsZ0NBQXlCLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRTtpQkFDckQsQ0FBQyxDQUFDO2dCQUNILElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLDRCQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUV6RCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsZ0JBQWdCLENBQUM7b0JBQ3pDLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxnQ0FBeUIsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFO2lCQUNyRCxDQUFDLENBQUM7Z0JBQ0gsSUFBQSxnQkFBTSxFQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsNEJBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBRXpELElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLDRCQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUV6RCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsZ0JBQWdCLENBQUM7b0JBQ3pDLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxnQ0FBeUIsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFO2lCQUN2RCxDQUFDLENBQUM7Z0JBQ0gsSUFBQSxnQkFBTSxFQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsNEJBQW9CLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBRTVELE1BQU0sR0FBRyxNQUFNLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDekMsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLFlBQVksRUFBRTtpQkFDN0IsQ0FBQyxDQUFDO2dCQUNILElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsNEJBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDdEQsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO2FBQU0sQ0FBQztZQUNKLElBQUEsWUFBRSxFQUFDLGtDQUFrQyxFQUFFLEtBQUssSUFBSSxFQUFFO2dCQUM5QyxNQUFNLE1BQU0sR0FBRyxNQUFNLFlBQVksQ0FBQyxlQUFlLENBQzdDLGlEQUFrRSxDQUNyRSxDQUFDO2dCQUVGLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMzRCxJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyw0QkFBb0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNuRSxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUEsa0JBQVEsRUFBQyxpQkFBaUIsRUFBRSxHQUFHLEVBQUU7UUFDN0IsSUFBSSxZQUEwQixDQUFDO1FBRS9CLElBQUEsbUJBQVMsRUFBQyxLQUFLLElBQUksRUFBRTtZQUNqQixNQUFNLGVBQWUsR0FBRyxFQUFFLEdBQUcsU0FBUyxFQUFnQyxDQUFDO1lBQ3ZFLFlBQVksR0FBRyxJQUFJLDRCQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxvQkFBVSxFQUFDLEdBQUcsRUFBRTtZQUNaLGNBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUEsWUFBRSxFQUFDLDZEQUE2RCxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3pFLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGVBQWUsQ0FDN0MsaURBQWtFLENBQ3JFLENBQUM7WUFFRixJQUFJLElBQUEseUJBQWMsR0FBRSxFQUFFLENBQUM7Z0JBQ25CLElBQUEsZ0JBQU0sRUFBQyx1QkFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUV0RDs7O1dBR0w7Z0JBRUssSUFBQSxnQkFBTSxFQUFDLHVCQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3REOzs7Ozs7Ozs7OztZQVdKO1lBQ0EsQ0FBQztZQUVELElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQ2xCLGdCQUFNLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3BCLFlBQVksRUFBRSxnQkFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7Z0JBQ2hDLGVBQWUsRUFBRTtvQkFDYixpQkFBaUIsRUFBRTt3QkFDZixXQUFXLEVBQUUsSUFBQSx5QkFBYyxHQUFFOzRCQUN6QixDQUFDLENBQUMsc0JBQVc7NEJBQ2IsQ0FBQyxDQUFDLGdCQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO3FCQUN2QztpQkFDSjthQUNKLENBQUMsQ0FDTCxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFBLFlBQUUsRUFBQyx1RUFBdUUsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNuRixNQUFNLE1BQU0sR0FBRyxNQUFNLFlBQVksQ0FBQyxlQUFlLENBQzdDLDJEQUE0RSxDQUMvRSxDQUFDO1lBQ0YsSUFBSSxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO2dCQUNuQixJQUFBLGdCQUFNLEVBQUMsdUJBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBRTdELElBQUEsZ0JBQU0sRUFBQyx1QkFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUN0RDs7Ozs7Ozs7YUFRSDtZQUNELENBQUM7WUFDRCxJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUN4QixDQUFDLElBQUEseUJBQWMsR0FBRTtnQkFDYixDQUFDLENBQUM7b0JBQ0ksWUFBWSxFQUFFLGdCQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztvQkFDaEMsZUFBZSxFQUFFLGdCQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztpQkFDdEM7Z0JBQ0gsQ0FBQyxDQUFDO29CQUNJLFlBQVksRUFBRSxnQkFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7aUJBQ25DLENBQ1YsQ0FBQztZQUNGLElBQUksQ0FBQyxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO2dCQUNwQixJQUFBLGdCQUFNLEVBQUUsTUFBZ0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMvRCxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBa0JDO1FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7U0FrQ0M7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUEsa0JBQVEsRUFBQyxrQkFBa0IsRUFBRSxHQUFHLEVBQUU7UUFDOUIsSUFBSSxZQUEwQixDQUFDO1FBRS9CLElBQUEsbUJBQVMsRUFBQyxLQUFLLElBQUksRUFBRTtZQUNqQixNQUFNLGVBQWUsR0FBRyxFQUFFLEdBQUcsU0FBUyxFQUFnQyxDQUFDO1lBQ3ZFLFlBQVksR0FBRyxJQUFJLDRCQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxvQkFBVSxFQUFDLEdBQUcsRUFBRTtZQUNaLGNBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUEsWUFBRSxFQUFDLGdCQUFnQixFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzVCLElBQUksQ0FBQyxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO2dCQUNwQixrQkFBa0IsR0FBRyxNQUFNLFlBQVksQ0FBQyxlQUFlLENBQ25ELGlEQUFrRSxDQUNyRSxDQUFDO1lBQ04sQ0FBQztZQUNELE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGdCQUFnQixDQUM5QyxJQUFBLHlCQUFjLEdBQUU7Z0JBQ1osQ0FBQyxDQUFFLGtDQUFxRDtnQkFDeEQsQ0FBQyxDQUFFO29CQUNHLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJO2lCQUNQLENBQ3BDLENBQUM7WUFFRixJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUN6QixJQUFJLEVBQUUsSUFBQSx5QkFBYyxHQUFFO29CQUNsQixDQUFDLENBQUMsa0NBQTJCO29CQUM3QixDQUFDLENBQUM7d0JBQ0ksRUFBRSxFQUFFLGdCQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDO3FCQUN4QztnQkFDUCxNQUFNLEVBQUUsSUFBQSx5QkFBYyxHQUFFO29CQUNwQixDQUFDLENBQUMsNEJBQW9CLENBQUMsVUFBVTtvQkFDakMsQ0FBQyxDQUFDLDRCQUFvQixDQUFDLGFBQWE7YUFDM0MsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUEsa0JBQVEsRUFBQyxlQUFlLEVBQUUsR0FBRyxFQUFFO1FBQzNCLElBQUEsbUJBQVMsRUFBQyxLQUFLLElBQUksRUFBRTtZQUNqQixNQUFNLGVBQWUsR0FBRyxFQUFFLEdBQUcsU0FBUyxFQUFnQyxDQUFDO1lBQ3ZFLFlBQVksR0FBRyxJQUFJLDRCQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxvQkFBVSxFQUFDLEdBQUcsRUFBRTtZQUNaLGNBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUEsWUFBRSxFQUFDLGdCQUFnQixFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzVCLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGFBQWEsQ0FBQztnQkFDNUMsSUFBSSxFQUFFLCtCQUF3QjthQUNqQyxDQUFDLENBQUM7WUFFSCxJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNuQixJQUFJLEVBQUUsa0JBQVUsQ0FBQyxxQkFBcUI7Z0JBQ3RDLEtBQUssRUFBRSwyREFBMkQ7YUFDckUsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFBLFlBQUUsRUFBQyxnRUFBZ0UsRUFBRSxLQUFLLElBQUksRUFBRTtZQUM1RSxNQUFNLE1BQU0sR0FBRyxNQUFNLFlBQVksQ0FBQyxhQUFhLENBQUM7Z0JBQzVDLElBQUksRUFBRSxxQ0FBOEI7YUFDdkMsQ0FBQyxDQUFDO1lBRUgsSUFBQSxnQkFBTSxFQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDbkIsSUFBSSxFQUFFLGtCQUFVLENBQUMscUJBQXFCO2dCQUN0QyxLQUFLLEVBQUUsMkRBQTJEO2FBQ3JFLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxZQUFFLEVBQUMsb0NBQW9DLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDaEQsTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsYUFBYSxDQUFDO2dCQUM1QyxJQUFJLEVBQUUsNEJBQXFCO2FBQzlCLENBQUMsQ0FBQztZQUVIOzs7O1dBSUQ7WUFDQyxJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNuQixJQUFJLEVBQUUsa0JBQVUsQ0FBQyxxQkFBcUI7Z0JBQ3RDLEtBQUssRUFBRSwyREFBMkQ7YUFDckUsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUEsa0JBQVEsRUFBQyxnQkFBZ0IsRUFBRSxHQUFHLEVBQUU7UUFDNUIsSUFBQSxtQkFBUyxFQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2pCLE1BQU0sZUFBZSxHQUFHLEVBQUUsR0FBRyxTQUFTLEVBQWdDLENBQUM7WUFDdkUsWUFBWSxHQUFHLElBQUksNEJBQVksQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDN0QsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFBLG9CQUFVLEVBQUMsR0FBRyxFQUFFO1lBQ1osY0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxZQUFFLEVBQUMsZ0JBQWdCLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDNUIsTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsY0FBYyxDQUM1QyxJQUFBLHlCQUFjLEdBQUU7Z0JBQ1osQ0FBQyxDQUFFLHVDQUFnQyxDQUFDLGtCQUEwQztnQkFDOUUsQ0FBQyxDQUFFO29CQUNHLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJO2lCQUNULENBQ2xDLENBQUM7WUFFRixJQUFJLElBQUEseUJBQWMsR0FBRSxFQUFFLENBQUM7Z0JBQ25CLElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUM7b0JBQ25CLEVBQUUsRUFBRSxnQ0FBeUIsQ0FBQyxTQUFTLENBQUMsRUFBRTtpQkFDN0MsQ0FBQyxDQUFDO1lBQ1AsQ0FBQztpQkFBTSxDQUFDO2dCQUNKLElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxhQUFhLENBQUM7b0JBQ3pCLFFBQVEsRUFBRSxnQkFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7aUJBQy9CLENBQUMsQ0FBQztZQUNQLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7U0FxQkM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUEsa0JBQVEsRUFBQyxlQUFlLEVBQUUsR0FBRyxFQUFFO1FBQzNCLElBQUEsbUJBQVMsRUFBQyxLQUFLLElBQUksRUFBRTtZQUNqQixNQUFNLGVBQWUsR0FBRyxFQUFFLEdBQUcsU0FBUyxFQUFnQyxDQUFDO1lBQ3ZFLFlBQVksR0FBRyxJQUFJLDRCQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxvQkFBVSxFQUFDLEdBQUcsRUFBRTtZQUNaLGNBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUEsWUFBRSxFQUFDLGdCQUFnQixFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzVCLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGFBQWEsQ0FBQztnQkFDNUMsSUFBSSxFQUFFLCtCQUF3QjthQUNqQyxDQUFDLENBQUM7WUFFSCxJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNuQixJQUFJLEVBQUUsc0NBQXNDO2dCQUM1QyxLQUFLLEVBQUUsMkRBQTJEO2FBQ3JFLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxZQUFFLEVBQUMsZ0VBQWdFLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDNUUsTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsYUFBYSxDQUFDO2dCQUM1QyxJQUFJLEVBQUUscUNBQThCO2FBQ3ZDLENBQUMsQ0FBQztZQUVILElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ25CLElBQUksRUFBRSxzQ0FBc0M7Z0JBQzVDLEtBQUssRUFBRSwyREFBMkQ7YUFDckUsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFBLFlBQUUsRUFBQyxvQ0FBb0MsRUFBRSxLQUFLLElBQUksRUFBRTtZQUNoRCxNQUFNLE1BQU0sR0FBRyxNQUFNLFlBQVksQ0FBQyxhQUFhLENBQUM7Z0JBQzVDLElBQUksRUFBRSw0QkFBcUI7YUFDOUIsQ0FBQyxDQUFDO1lBRUgsSUFBQSxnQkFBTSxFQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDbkIsSUFBSSxFQUFFLHNDQUFzQztnQkFDNUMsS0FBSyxFQUFFLDJEQUEyRDthQUNyRSxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0lBRUgsSUFBQSxrQkFBUSxFQUFDLGVBQWUsRUFBRSxHQUFHLEVBQUU7UUFDM0IsSUFBQSxtQkFBUyxFQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2pCLE1BQU0sZUFBZSxHQUFHLEVBQUUsR0FBRyxTQUFTLEVBQWdDLENBQUs7WUFDM0UsWUFBWSxHQUFHLElBQUksNEJBQVksQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDN0QsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFBLG9CQUFVLEVBQUMsR0FBRyxFQUFFO1lBQ1osY0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxZQUFFLEVBQUMsZ0JBQWdCLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDNUIsTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsYUFBYSxDQUMzQyxJQUFBLHlCQUFjLEdBQUU7Z0JBQ1osQ0FBQyxDQUFFO29CQUNHLElBQUksRUFBRSwrQkFBd0I7b0JBQzlCLE1BQU0sRUFBRSxHQUFHO2lCQUNTO2dCQUMxQixDQUFDLENBQUU7b0JBQ0csSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUk7b0JBQzlCLE1BQU0sRUFBRSxHQUFHO2lCQUNTLENBQ2pDLENBQUM7WUFDRixJQUFJLElBQUEseUJBQWMsR0FBRSxFQUFFLENBQUM7Z0JBQ25CLElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxhQUFhLENBQUM7b0JBQ3pCLFNBQVMsRUFBRSxnQ0FBeUIsQ0FBQyxTQUFTLENBQUMsRUFBRTtpQkFDcEQsQ0FBQyxDQUFDO1lBQ1AsQ0FBQztpQkFBTSxDQUFDO2dCQUNKLElBQUEsZ0JBQU0sRUFBQyxNQUFNLENBQUMsQ0FBQyxhQUFhLENBQUM7b0JBQ3pCLFFBQVEsRUFBRSxnQkFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7aUJBQy9CLENBQUMsQ0FBQztZQUNQLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVIOzs7Ozs7Ozs7OztVQVdFO0lBQ04sQ0FBQyxDQUFDLENBQUM7SUFFSCxJQUFBLGtCQUFRLEVBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFO1FBQzdCLElBQUEsbUJBQVMsRUFBQyxLQUFLLElBQUksRUFBRTtZQUNqQixNQUFNLGVBQWUsR0FBRyxFQUFFLEdBQUcsU0FBUyxFQUFnQyxDQUFDO1lBQ3ZFLFlBQVksR0FBRyxJQUFJLDRCQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBQSxvQkFBVSxFQUFDLEdBQUcsRUFBRTtZQUNaLGNBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUEsWUFBRSxFQUFDLGlCQUFpQixFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzdCLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGVBQWUsQ0FDN0MsSUFBQSx5QkFBYyxHQUFFO2dCQUNaLENBQUMsQ0FBRSxpQ0FBbUQ7Z0JBQ3RELENBQUMsQ0FBRTtvQkFDRyxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSTtpQkFDUixDQUNuQyxDQUFDO1lBQ0YsSUFBSSxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO2dCQUNuQixJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUFDO29CQUN6QixNQUFNLEVBQUUsV0FBVztpQkFDdEIsQ0FBQyxDQUFDO1lBQ1AsQ0FBQztpQkFBTSxDQUFDO2dCQUNKLE1BQU0sY0FBYyxHQUFHLE1BQStCLENBQUM7Z0JBQ3ZELElBQUEsZ0JBQU0sRUFBQyxjQUFjLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUM5QyxJQUFBLGdCQUFNLEVBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEQsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUg7Ozs7Ozs7Ozs7U0FVQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsSUFBSSxDQUFDLElBQUEseUJBQWMsR0FBRSxFQUFFLENBQUM7UUFDcEIsSUFBQSxrQkFBUSxFQUFDLGVBQWUsRUFBRSxHQUFHLEVBQUU7WUFDM0IsSUFBSSxDQUFDLElBQUEseUJBQWMsR0FBRSxFQUFFLENBQUM7Z0JBQ3BCLElBQUEsbUJBQVMsRUFBQyxLQUFLLElBQUksRUFBRTtvQkFDakIsTUFBTSxlQUFlLEdBQUcsRUFBRSxHQUFHLFNBQVMsRUFBZ0MsQ0FBQztvQkFDdkUsWUFBWSxHQUFHLElBQUksNEJBQVksQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQzdELENBQUMsQ0FBQyxDQUFDO2dCQUVILElBQUEsb0JBQVUsRUFBQyxHQUFHLEVBQUU7b0JBQ1osY0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN6QixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUM7WUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dCQTBDSTtZQUVKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztNQWdDTjtZQUNNLElBQUksQ0FBQyxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO2dCQUNwQixJQUFBLFlBQUUsRUFBQyx5REFBeUQsRUFBRSxLQUFLLElBQUksRUFBRTtvQkFDckUsTUFBTSxjQUFjLEdBQXVCO3dCQUN2QyxhQUFhLEVBQ1QsOENBQXVDLENBQUMsYUFBYTt3QkFDekQsTUFBTSxFQUFFLDhDQUF1QyxDQUFDLE1BQU07d0JBRXRELE9BQU8sRUFBRTs0QkFDTCxRQUFRLEVBQUU7Z0NBQ04sS0FBSyxFQUFFLDhDQUF1QyxDQUFDLEtBQUs7Z0NBQ3BELEVBQUUsRUFBRSw4Q0FBdUMsQ0FBQyxXQUFXOzZCQUMxRDs0QkFDRCxXQUFXOzRCQUNYLG1CQUFtQjs0QkFDbkIsK0RBQStEOzRCQUMvRCxlQUFlOzRCQUNmLDJEQUEyRDs0QkFDM0QsMkNBQTJDOzRCQUMzQyx1RUFBdUU7NEJBQ3ZFLDRDQUE0Qzs0QkFDNUMsSUFBSTt5QkFDUDtxQkFDSixDQUFDO29CQUNGLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLGFBQWEsQ0FDM0MsSUFBQSx5QkFBYyxHQUFFO3dCQUNaLENBQUMsQ0FBRSw4Q0FBOEQ7d0JBQ2pFLENBQUMsQ0FBQyxjQUFjLENBQ3ZCLENBQUM7b0JBQ0YsSUFBSSxJQUFBLHlCQUFjLEdBQUUsRUFBRSxDQUFDO3dCQUNuQixJQUFBLGdCQUFNLEVBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7d0JBQzdDLHVEQUF1RDt3QkFDdkQ7Ozs7O1lBS1o7b0JBQ1EsQ0FBQztvQkFDRCxJQUFBLGdCQUFNLEVBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUFDO3dCQUN6QixZQUFZLEVBQUU7NEJBQ1YsTUFBTSxFQUFFLDhDQUF1QyxDQUFDLE1BQU07eUJBQ3pEO3FCQUNKLENBQUMsQ0FBQztnQkFDUCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDYixDQUFDO1lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQWtCSDtRQUNELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDhDQUE4QztJQUM5Qyw4QkFBOEI7SUFDOUIsb0RBQW9EO0lBQ3BELG9FQUFvRTtJQUNwRSxVQUFVO0lBRVYseUJBQXlCO0lBQ3pCLGdDQUFnQztJQUNoQyxVQUFVO0lBRVYsaUVBQWlFO0lBQ2pFLHdDQUF3QztJQUN4QyxvRUFBb0U7SUFDcEUsa0VBQWtFO0lBRWxFLGdEQUFnRDtJQUNoRCwrQkFBK0I7SUFDL0IsaUVBQWlFO0lBQ2pFLG9EQUFvRDtJQUNwRCxnQkFBZ0I7SUFDaEIsMkJBQTJCO0lBQzNCLDhDQUE4QztJQUM5QyxrQ0FBa0M7SUFDbEMsOENBQThDO0lBQzlDLGdCQUFnQjtJQUNoQixhQUFhO0lBQ2Isa0NBQWtDO0lBQ2xDLHlFQUF5RTtJQUN6RSxZQUFZO0lBQ1osZ0JBQWdCO0lBRWhCLG9FQUFvRTtJQUNwRSx3Q0FBd0M7SUFDeEMsa0JBQWtCO0lBQ2xCLDRCQUE0QjtJQUM1QiwrREFBK0Q7SUFDL0QsaURBQWlEO0lBQ2pELHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsMkRBQTJEO0lBRTNELGdEQUFnRDtJQUNoRCwrQkFBK0I7SUFDL0IsaUVBQWlFO0lBQ2pFLG9EQUFvRDtJQUNwRCxnQkFBZ0I7SUFDaEIsMkJBQTJCO0lBQzNCLDhDQUE4QztJQUM5QyxrQ0FBa0M7SUFDbEMsOENBQThDO0lBQzlDLGdCQUFnQjtJQUNoQixhQUFhO0lBQ2Isa0NBQWtDO0lBQ2xDLG1FQUFtRTtJQUNuRSxZQUFZO0lBQ1osZ0JBQWdCO0lBRWhCOzs7Ozs7Ozs7Ozs7O1NBYUs7SUFDTCxTQUFTO0FBQ2IsQ0FBQyxDQUFDLENBQUMifQ==