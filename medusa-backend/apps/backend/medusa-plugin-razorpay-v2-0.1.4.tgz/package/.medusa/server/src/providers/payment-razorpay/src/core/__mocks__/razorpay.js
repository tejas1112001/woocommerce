"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RazorpayMock = exports.RAZORPAY_ID = exports.FAIL_INTENT_ID = exports.PARTIALLY_FAIL_INTENT_ID = exports.EXISTING_CUSTOMER_EMAIL = exports.WRONG_CUSTOMER_EMAIL = void 0;
exports.isMocksEnabled = isMocksEnabled;
const globals_1 = require("@jest/globals");
const razorpay_1 = __importDefault(require("razorpay"));
const types_1 = require("../../types");
const data_1 = require("../__fixtures__/data");
exports.WRONG_CUSTOMER_EMAIL = "wrong@test.fr";
exports.EXISTING_CUSTOMER_EMAIL = "right@test.fr";
exports.PARTIALLY_FAIL_INTENT_ID = "partially_unknown";
exports.FAIL_INTENT_ID = "unknown";
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const mockEnabled = process.env.DISABLE_MOCKS !== "true";
function isMocksEnabled() {
    if (mockEnabled) {
        console.log("using mocks");
    }
    return mockEnabled;
}
exports.RAZORPAY_ID = isMocksEnabled() ? "test" : process.env.RAZORPAY_ID;
exports.RazorpayMock = {
    orders: {
        fetch: globals_1.jest
            .fn()
            .mockImplementation(async (orderId) => {
            if (orderId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            return (Object.values(data_1.PaymentIntentDataByStatus).find((value) => {
                return value.id === orderId;
            }) ?? {});
        }),
        fetchPayments: globals_1.jest
            .fn()
            .mockImplementation(async (orderId) => {
            if (orderId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            const orderData = Object.values(data_1.PaymentIntentDataByStatus).find((value) => {
                return value.id === orderId;
            });
            return {
                items: orderData
                    ? [orderData]
                    : []
            };
        }),
        edit: globals_1.jest
            .fn()
            .mockImplementation(async (orderId, updateData) => {
            if (orderId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            const data = Object.values(data_1.PaymentIntentDataByStatus).find((value) => {
                return value.id === orderId;
            }) ?? {};
            return {
                ...data,
                ...updateData
            };
        }),
        create: globals_1.jest
            .fn()
            .mockImplementation(async (data) => {
            const requestData = data;
            if (requestData.description === "fail") {
                throw new Error("Error");
            }
            return requestData;
        })
    },
    payments: {
        fetch: globals_1.jest
            .fn()
            .mockImplementation(async (paymentId) => {
            if (paymentId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            return (Object.values(data_1.PaymentIntentDataByStatus).find((value) => {
                return value.id === paymentId;
            }) ?? {});
        }),
        edit: globals_1.jest
            .fn()
            .mockImplementation(async (paymentId, updateData) => {
            if (paymentId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            const data = Object.values(data_1.PaymentIntentDataByStatus).find((value) => {
                return value.id === paymentId;
            }) ?? {};
            return {
                ...data,
                ...updateData
            };
        }),
        create: globals_1.jest
            .fn()
            .mockImplementation(async (data) => {
            const requestData = data;
            if (requestData.description === "fail") {
                throw new Error("Error");
            }
            return requestData;
        }),
        cancel: globals_1.jest
            .fn()
            .mockImplementation(async (paymentId) => {
            if (paymentId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            if (paymentId === exports.PARTIALLY_FAIL_INTENT_ID) {
                throw new Error(JSON.stringify({
                    code: types_1.ErrorCodes.PAYMENT_INTENT_UNEXPECTED_STATE,
                    payment_intent: {
                        id: paymentId,
                        status: types_1.ErrorIntentStatus.CANCELED
                    },
                    type: "invalid_request_error"
                }));
            }
            return { id: paymentId };
        }),
        capture: globals_1.jest
            .fn()
            .mockImplementation(async (paymentId, amount, currency) => {
            if (paymentId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            if (paymentId === exports.PARTIALLY_FAIL_INTENT_ID) {
                throw new Error(JSON.stringify({
                    code: types_1.ErrorCodes.PAYMENT_INTENT_UNEXPECTED_STATE,
                    payment_intent: {
                        id: paymentId,
                        status: types_1.ErrorIntentStatus.SUCCEEDED
                    },
                    type: "invalid_request_error"
                }));
            }
            return {
                id: paymentId,
                amount: amount,
                currency: currency
            };
        }),
        refund: globals_1.jest
            .fn()
            .mockImplementation(async (paymentId) => {
            if (paymentId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            return {
                id: paymentId,
                payment_id: paymentId
            };
        })
    },
    refunds: {
        fetch: globals_1.jest
            .fn()
            .mockImplementation(async (refundId) => {
            if (refundId === exports.FAIL_INTENT_ID) {
                throw new Error("Error");
            }
            return (Object.values(data_1.PaymentIntentDataByStatus).find((value) => {
                return value.id === refundId;
            }) ?? {});
        })
    },
    customers: {
        create: globals_1.jest
            .fn()
            .mockImplementation(async (data) => {
            const requestData = data;
            if (requestData.email === exports.EXISTING_CUSTOMER_EMAIL) {
                return {
                    id: exports.RAZORPAY_ID,
                    ...requestData
                };
            }
            throw new Error("Error");
        }),
        fetch: globals_1.jest
            .fn()
            .mockImplementation(async (customerId) => {
            const customer = {
                id: customerId,
                entity: "customer",
                created_at: 0,
                name: "test customer",
                email: exports.EXISTING_CUSTOMER_EMAIL,
                contact: "9876543210"
            };
            return Promise.resolve(customer);
        }),
        edit: globals_1.jest
            .fn()
            .mockImplementation(async (id, data) => {
            const updateData = data;
            const customer = {
                id: id,
                entity: "customer",
                created_at: 0,
                name: updateData.name ?? "test customer",
                email: updateData.email ?? exports.EXISTING_CUSTOMER_EMAIL,
                contact: updateData.contact ?? "9876543210"
            };
            return Promise.resolve(customer);
        })
    }
};
const razorpay = isMocksEnabled() ? globals_1.jest.fn(() => exports.RazorpayMock) : razorpay_1.default;
exports.default = razorpay;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmF6b3JwYXkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvcHJvdmlkZXJzL3BheW1lbnQtcmF6b3JwYXkvc3JjL2NvcmUvX19tb2Nrc19fL3Jhem9ycGF5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQW1CQSx3Q0FLQztBQXhCRCwyQ0FBcUM7QUFDckMsd0RBQWdDO0FBQ2hDLHVDQUE0RDtBQUM1RCwrQ0FBaUU7QUFDcEQsUUFBQSxvQkFBb0IsR0FBRyxlQUFlLENBQUM7QUFDdkMsUUFBQSx1QkFBdUIsR0FBRyxlQUFlLENBQUM7QUFDMUMsUUFBQSx3QkFBd0IsR0FBRyxtQkFBbUIsQ0FBQztBQUMvQyxRQUFBLGNBQWMsR0FBRyxTQUFTLENBQUM7QUFFeEMsb0RBQTRCO0FBTTVCLGdCQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7QUFFaEIsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEtBQUssTUFBTSxDQUFDO0FBRXpELFNBQWdCLGNBQWM7SUFDMUIsSUFBSSxXQUFXLEVBQUUsQ0FBQztRQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUNELE9BQU8sV0FBVyxDQUFDO0FBQ3ZCLENBQUM7QUFDWSxRQUFBLFdBQVcsR0FBRyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztBQUVsRSxRQUFBLFlBQVksR0FBRztJQUN4QixNQUFNLEVBQUU7UUFDSixLQUFLLEVBQUUsY0FBSTthQUNOLEVBQUUsRUFBRTthQUNKLGtCQUFrQixDQUNmLEtBQUssRUFBRSxPQUFnQixFQUFpQyxFQUFFO1lBQ3RELElBQUksT0FBTyxLQUFLLHNCQUFjLEVBQUUsQ0FBQztnQkFDN0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3QixDQUFDO1lBRUQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQXlCLENBQUMsQ0FBQyxJQUFJLENBQ2pELENBQUMsS0FBSyxFQUFFLEVBQUU7Z0JBQ04sT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQztZQUNoQyxDQUFDLENBQ0osSUFBSSxFQUFFLENBQXlCLENBQUM7UUFDckMsQ0FBQyxDQUNKO1FBQ0wsYUFBYSxFQUFFLGNBQUk7YUFDZCxFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQ0QsT0FBZ0IsRUFDbUMsRUFBRTtZQUNyRCxJQUFJLE9BQU8sS0FBSyxzQkFBYyxFQUFFLENBQUM7Z0JBQzdCLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0IsQ0FBQztZQUVELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQzNCLGdDQUF5QixDQUM1QixDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFO2dCQUNiLE9BQU8sS0FBSyxDQUFDLEVBQUUsS0FBSyxPQUFPLENBQUM7WUFDaEMsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPO2dCQUNILEtBQUssRUFBRSxTQUFTO29CQUNaLENBQUMsQ0FBQyxDQUFDLFNBQXFDLENBQUM7b0JBQ3pDLENBQUMsQ0FBQyxFQUFFO2FBQ1gsQ0FBQztRQUNOLENBQUMsQ0FDSjtRQUNMLElBQUksRUFBRSxjQUFJO2FBQ0wsRUFBRSxFQUFFO2FBQ0osa0JBQWtCLENBQ2YsS0FBSyxFQUNELE9BQWdCLEVBQ2hCLFVBQW1CLEVBQ1UsRUFBRTtZQUMvQixJQUFJLE9BQU8sS0FBSyxzQkFBYyxFQUFFLENBQUM7Z0JBQzdCLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0IsQ0FBQztZQUVELE1BQU0sSUFBSSxHQUNOLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQXlCLENBQUMsQ0FBQyxJQUFJLENBQ3pDLENBQUMsS0FBSyxFQUFFLEVBQUU7Z0JBQ04sT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQztZQUNoQyxDQUFDLENBQ0osSUFBSSxFQUFFLENBQUM7WUFFWixPQUFPO2dCQUNILEdBQUcsSUFBSTtnQkFDUCxHQUFJLFVBQXNDO2FBQ3JCLENBQUM7UUFDOUIsQ0FBQyxDQUNKO1FBQ0wsTUFBTSxFQUFFLGNBQUk7YUFDUCxFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQUUsSUFBYSxFQUFpQyxFQUFFO1lBQ25ELE1BQU0sV0FBVyxHQUNiLElBRUMsQ0FBQztZQUNOLElBQUksV0FBVyxDQUFDLFdBQVcsS0FBSyxNQUFNLEVBQUUsQ0FBQztnQkFDckMsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3QixDQUFDO1lBRUQsT0FBTyxXQUFtQyxDQUFDO1FBQy9DLENBQUMsQ0FDSjtLQUNSO0lBRUQsUUFBUSxFQUFFO1FBQ04sS0FBSyxFQUFFLGNBQUk7YUFDTixFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQ0QsU0FBa0IsRUFDZSxFQUFFO1lBQ25DLElBQUksU0FBUyxLQUFLLHNCQUFjLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3QixDQUFDO1lBRUQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQXlCLENBQUMsQ0FBQyxJQUFJLENBQ2pELENBQUMsS0FBSyxFQUFFLEVBQUU7Z0JBQ04sT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQztZQUNsQyxDQUFDLENBQ0osSUFBSSxFQUFFLENBQTZCLENBQUM7UUFDekMsQ0FBQyxDQUNKO1FBQ0wsSUFBSSxFQUFFLGNBQUk7YUFDTCxFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQ0QsU0FBa0IsRUFDbEIsVUFBbUIsRUFDYyxFQUFFO1lBQ25DLElBQUksU0FBUyxLQUFLLHNCQUFjLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3QixDQUFDO1lBRUQsTUFBTSxJQUFJLEdBQ04sTUFBTSxDQUFDLE1BQU0sQ0FBQyxnQ0FBeUIsQ0FBQyxDQUFDLElBQUksQ0FDekMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtnQkFDTixPQUFPLEtBQUssQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDO1lBQ2xDLENBQUMsQ0FDSixJQUFJLEVBQUUsQ0FBQztZQUVaLE9BQU87Z0JBQ0gsR0FBRyxJQUFJO2dCQUNQLEdBQUksVUFBc0M7YUFDakIsQ0FBQztRQUNsQyxDQUFDLENBQ0o7UUFDTCxNQUFNLEVBQUUsY0FBSTthQUNQLEVBQUUsRUFBRTthQUNKLGtCQUFrQixDQUNmLEtBQUssRUFBRSxJQUFhLEVBQXFDLEVBQUU7WUFDdkQsTUFBTSxXQUFXLEdBQ2IsSUFFQyxDQUFDO1lBQ04sSUFBSSxXQUFXLENBQUMsV0FBVyxLQUFLLE1BQU0sRUFBRSxDQUFDO2dCQUNyQyxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdCLENBQUM7WUFFRCxPQUFPLFdBQXVDLENBQUM7UUFDbkQsQ0FBQyxDQUNKO1FBQ0wsTUFBTSxFQUFFLGNBQUk7YUFDUCxFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQ0QsU0FBa0IsRUFDZSxFQUFFO1lBQ25DLElBQUksU0FBUyxLQUFLLHNCQUFjLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3QixDQUFDO1lBRUQsSUFBSSxTQUFTLEtBQUssZ0NBQXdCLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxJQUFJLEtBQUssQ0FDWCxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNYLElBQUksRUFBRSxrQkFBVSxDQUFDLCtCQUErQjtvQkFDaEQsY0FBYyxFQUFFO3dCQUNaLEVBQUUsRUFBRSxTQUFTO3dCQUNiLE1BQU0sRUFBRSx5QkFBaUIsQ0FBQyxRQUFRO3FCQUNyQztvQkFDRCxJQUFJLEVBQUUsdUJBQXVCO2lCQUNoQyxDQUFDLENBQ0wsQ0FBQztZQUNOLENBQUM7WUFFRCxPQUFPLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBOEIsQ0FBQztRQUN6RCxDQUFDLENBQ0o7UUFDTCxPQUFPLEVBQUUsY0FBSTthQUNSLEVBQUUsRUFBRTthQUNKLGtCQUFrQixDQUNmLEtBQUssRUFDRCxTQUFrQixFQUNsQixNQUFlLEVBQ2YsUUFBaUIsRUFDZ0IsRUFBRTtZQUNuQyxJQUFJLFNBQVMsS0FBSyxzQkFBYyxFQUFFLENBQUM7Z0JBQy9CLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0IsQ0FBQztZQUVELElBQUksU0FBUyxLQUFLLGdDQUF3QixFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sSUFBSSxLQUFLLENBQ1gsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQkFDWCxJQUFJLEVBQUUsa0JBQVUsQ0FBQywrQkFBK0I7b0JBQ2hELGNBQWMsRUFBRTt3QkFDWixFQUFFLEVBQUUsU0FBUzt3QkFDYixNQUFNLEVBQUUseUJBQWlCLENBQUMsU0FBUztxQkFDdEM7b0JBQ0QsSUFBSSxFQUFFLHVCQUF1QjtpQkFDaEMsQ0FBQyxDQUNMLENBQUM7WUFDTixDQUFDO1lBRUQsT0FBTztnQkFDSCxFQUFFLEVBQUUsU0FBUztnQkFDYixNQUFNLEVBQUUsTUFBZ0I7Z0JBQ3hCLFFBQVEsRUFBRSxRQUFrQjthQUNILENBQUM7UUFDbEMsQ0FBQyxDQUNKO1FBQ0wsTUFBTSxFQUFFLGNBQUk7YUFDUCxFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQUUsU0FBa0IsRUFBbUMsRUFBRTtZQUMxRCxJQUFJLFNBQVMsS0FBSyxzQkFBYyxFQUFFLENBQUM7Z0JBQy9CLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0IsQ0FBQztZQUVELE9BQU87Z0JBQ0gsRUFBRSxFQUFFLFNBQW1CO2dCQUN2QixVQUFVLEVBQUUsU0FBbUI7YUFDUixDQUFDO1FBQ2hDLENBQUMsQ0FDSjtLQUNSO0lBQ0QsT0FBTyxFQUFFO1FBQ0wsS0FBSyxFQUFFLGNBQUk7YUFDTixFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQUUsUUFBaUIsRUFBbUMsRUFBRTtZQUN6RCxJQUFJLFFBQVEsS0FBSyxzQkFBYyxFQUFFLENBQUM7Z0JBQzlCLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0IsQ0FBQztZQUVELE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGdDQUF5QixDQUFDLENBQUMsSUFBSSxDQUNqRCxDQUFDLEtBQUssRUFBRSxFQUFFO2dCQUNOLE9BQU8sS0FBSyxDQUFDLEVBQUUsS0FBSyxRQUFRLENBQUM7WUFDakMsQ0FBQyxDQUNKLElBQUksRUFBRSxDQUEyQixDQUFDO1FBQ3ZDLENBQUMsQ0FDSjtLQUNSO0lBQ0QsU0FBUyxFQUFFO1FBQ1AsTUFBTSxFQUFFLGNBQUk7YUFDUCxFQUFFLEVBQUU7YUFDSixrQkFBa0IsQ0FDZixLQUFLLEVBQUUsSUFBYSxFQUF1QyxFQUFFO1lBQ3pELE1BQU0sV0FBVyxHQUNiLElBQW1ELENBQUM7WUFDeEQsSUFBSSxXQUFXLENBQUMsS0FBSyxLQUFLLCtCQUF1QixFQUFFLENBQUM7Z0JBQ2hELE9BQU87b0JBQ0gsRUFBRSxFQUFFLG1CQUFXO29CQUNmLEdBQUcsV0FBVztpQkFDYSxDQUFDO1lBQ3BDLENBQUM7WUFFRCxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FDSjtRQUNMLEtBQUssRUFBRSxjQUFJO2FBQ04sRUFBRSxFQUFFO2FBQ0osa0JBQWtCLENBQ2YsS0FBSyxFQUNELFVBQW1CLEVBQ2dCLEVBQUU7WUFDckMsTUFBTSxRQUFRLEdBQStCO2dCQUN6QyxFQUFFLEVBQUUsVUFBb0I7Z0JBQ3hCLE1BQU0sRUFBRSxVQUFVO2dCQUNsQixVQUFVLEVBQUUsQ0FBQztnQkFDYixJQUFJLEVBQUUsZUFBZTtnQkFDckIsS0FBSyxFQUFFLCtCQUF1QjtnQkFDOUIsT0FBTyxFQUFFLFlBQVk7YUFDeEIsQ0FBQztZQUNGLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQ0o7UUFDTCxJQUFJLEVBQUUsY0FBSTthQUNMLEVBQUUsRUFBRTthQUNKLGtCQUFrQixDQUNmLEtBQUssRUFDRCxFQUFXLEVBQ1gsSUFBYSxFQUNzQixFQUFFO1lBQ3JDLE1BQU0sVUFBVSxHQUNaLElBQW1ELENBQUM7WUFDeEQsTUFBTSxRQUFRLEdBQStCO2dCQUN6QyxFQUFFLEVBQUUsRUFBWTtnQkFDaEIsTUFBTSxFQUFFLFVBQVU7Z0JBQ2xCLFVBQVUsRUFBRSxDQUFDO2dCQUNiLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxJQUFJLGVBQWU7Z0JBQ3hDLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxJQUFJLCtCQUF1QjtnQkFDbEQsT0FBTyxFQUFFLFVBQVUsQ0FBQyxPQUFPLElBQUksWUFBWTthQUM5QyxDQUFDO1lBQ0YsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FDSjtLQUNSO0NBQ0osQ0FBQztBQUVGLE1BQU0sUUFBUSxHQUFHLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLG9CQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQVEsQ0FBQztBQUUzRSxrQkFBZSxRQUFRLENBQUMifQ==