"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const razorpay_1 = __importDefault(require("razorpay"));
const get_smallest_unit_1 = require("../utils/get-smallest-unit");
const update_razorpay_customer_metadata_1 = require("../workflows/update-razorpay-customer-metadata");
class RazorpayBase extends utils_1.AbstractPaymentProvider {
    constructor(container, options) {
        super(container, options);
        this.options_ = options;
        this.logger = container[utils_1.ContainerRegistrationKeys.LOGGER];
        this.paymentService = container[utils_1.Modules.PAYMENT];
        this.container_ = container;
        this.options_ = options;
        this.init();
    }
    init() {
        const provider = this.options_.providers?.find((p) => p.id === RazorpayBase.identifier);
        if (!provider && !this.options_.key_id) {
            throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "razorpay not configured", utils_1.MedusaErrorCodes.CART_INCOMPATIBLE_STATE);
        }
        this.razorpay_ =
            this.razorpay_ ||
                new razorpay_1.default({
                    key_id: this.options_.key_id ?? provider?.options.key_id,
                    key_secret: this.options_.key_secret ?? provider?.options.key_secret,
                    headers: {
                        "Content-Type": "application/json",
                        "X-Razorpay-Account": this.options_.razorpay_account ??
                            provider?.options.razorpay_account ??
                            undefined
                    }
                });
    }
    static validateOptions(options) {
        if (!(0, utils_1.isDefined)(options.key_id)) {
            throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "Required option `key_id` is missing in Razorpay plugin");
        }
        if (!(0, utils_1.isDefined)(options.key_secret)) {
            throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "Required option `key_secret` is missing in Razorpay plugin");
        }
        if (!(0, utils_1.isDefined)(options.razorpay_account)) {
            throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "Required option `razorpay_account` is missing in Razorpay plugin");
        }
        if (!(0, utils_1.isDefined)(options.automatic_expiry_period)) {
            if (!(0, utils_1.isDefined)(options.manual_expiry_period)) {
                throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "Required option `manual_expiry_period` is missing in Razorpay plugin");
            }
            throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "Required option `automatic_expiry_period` is missing in Razorpay plugin");
        }
        if (!(0, utils_1.isDefined)(options.webhook_secret)) {
            throw new utils_1.MedusaError(utils_1.MedusaErrorTypes.INVALID_ARGUMENT, "Required option `webhook_secret` is missing in Razorpay plugin");
        }
    }
    async capturePayment(input) {
        const { razorpayOrder, paymentSession } = await this.getPaymentSessionAndOrderFromInput(input);
        const paymentsResponse = await this.razorpay_.orders.fetchPayments(razorpayOrder.id);
        const possibleCaptures = paymentsResponse.items?.filter((item) => item.status === "authorized");
        const result = possibleCaptures?.map(async (payment) => {
            const { id, amount, currency } = payment;
            const toPay = this.getToPay(amount, currency);
            const paymentCaptured = await this.razorpay_.payments.capture(id, toPay, currency);
            return paymentCaptured;
        });
        if (result) {
            const syncResult = await this.syncPaymentSession(paymentSession.id, razorpayOrder.id);
            const returrnedResult = {
                data: {
                    razorpayOrder: syncResult.razorpayOrder
                }
            };
            return returrnedResult;
        }
        else {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `No payments found for order ${razorpayOrder.id}`);
        }
    }
    async authorizePayment(input) {
        const { razorpayOrder, paymentSession } = await this.getPaymentSessionAndOrderFromInput(input);
        const paymentStatusRequest = {
            ...input
        };
        const status = await this.getPaymentStatus(paymentStatusRequest);
        const result = await this.syncPaymentSession(paymentSession.id, razorpayOrder.id);
        if (status.status === utils_1.PaymentSessionStatus.AUTHORIZED &&
            this.options_.auto_capture) {
            status.status = utils_1.PaymentSessionStatus.CAPTURED;
        }
        return {
            data: {
                razorpayOrder: result.razorpayOrder
            },
            status: status.status
        };
    }
    async cancelPayment(input) {
        const { razorpayOrder, paymentSession } = await this.getPaymentSessionAndOrderFromInput(input);
        const fetchPayments = await this.razorpay_.orders.fetchPayments(razorpayOrder.id);
        const capturedPayments = fetchPayments.items?.filter((item) => item.status === "captured");
        if (capturedPayments.length !== 0) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "Cannot cancel a payment that has been captured");
        }
        const possibleRefunds = fetchPayments.items?.filter((item) => item.status === "authorized");
        const result = await Promise.all(possibleRefunds?.map(async (payment) => {
            const { id, amount, currency } = payment;
            const toPay = this.getToPay(amount, currency);
            const refund = await this.razorpay_.payments.refund(id, {
                amount: toPay,
                notes: {
                    medusa_payment_session_id: paymentSession.id
                }
            });
            return refund;
        }));
        const syncResult = await this.syncPaymentSession(paymentSession.id, razorpayOrder.id);
        return {
            data: {
                razorpayOrder: syncResult.razorpayOrder,
                razorpayRefunds: result
            }
        };
    }
    async getPaymentSessionAndOrderFromInput(input) {
        let { data, context } = input;
        if (!data?.razorpayorder) {
            if (data?.id) {
                data = {
                    ...data,
                    razorpayOrder: await this.razorpay_.orders.fetch(data.id)
                };
            }
        }
        let { razorpayOrder } = data;
        const paymentSessionId = razorpayOrder?.notes
            ?.medusa_payment_session_id ?? context?.idempotency_key;
        const paymentSession = await this.paymentService.retrievePaymentSession(paymentSessionId);
        if (!razorpayOrder) {
            razorpayOrder = paymentSession?.data
                ?.razorpayOrder;
        }
        if (razorpayOrder) {
            const razorpayOrder_latest = await this.razorpay_.orders.fetch(razorpayOrder.id);
            if (razorpayOrder_latest.status !== razorpayOrder.status) {
                razorpayOrder = razorpayOrder_latest;
            }
        }
        return {
            paymentSession,
            razorpayOrder: razorpayOrder
        };
    }
    getRazorpayOrderCreateRequestBody(amount, currency_code) {
        const intentRequest = {
            amount: amount,
            currency: currency_code.toUpperCase(),
            payment: {
                capture: (this.options_.auto_capture ?? true)
                    ? "automatic"
                    : "manual",
                capture_options: {
                    refund_speed: this.options_.refund_speed ?? "normal",
                    automatic_expiry_period: Math.max(this.options_.automatic_expiry_period ?? 20, 12),
                    manual_expiry_period: Math.max(this.options_.manual_expiry_period ?? 10, 7200)
                }
            }
        };
        return intentRequest;
    }
    async syncPaymentSession(paymentSessionId, razorpayOrderId) {
        const orderData = await this.updateRazorpayOrderMetadata(razorpayOrderId, {
            medusa_payment_session_id: paymentSessionId
        });
        const paymentSessionData = await this.paymentService.retrievePaymentSession(paymentSessionId);
        return {
            razorpayOrder: orderData,
            paymentSession: paymentSessionData
        };
    }
    getToPay(amount, currency_code) {
        return Math.round((0, get_smallest_unit_1.getAmountFromSmallestUnit)(Math.round(parseInt(amount.toString(), 10)), currency_code.toUpperCase()) * 100 * 100);
    }
    async initiatePayment(input) {
        const paymentSessionId = input.context?.idempotency_key;
        const { amount, currency_code } = input;
        const toPay = this.getToPay(amount, currency_code);
        try {
            const razorpayOrderCreateRequest = this.getRazorpayOrderCreateRequestBody(toPay, currency_code);
            const razorpayOrder = await this.razorpay_.orders.create(razorpayOrderCreateRequest);
            if (!paymentSessionId) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "Payment session ID is required");
            }
            return {
                id: paymentSessionId,
                data: { razorpayOrder: razorpayOrder }
            };
        }
        catch (error) {
            this.logger.error(`Error creating Razorpay order: ${error.message}`, error);
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `Failed to create Razorpay order: ${error.message}`);
        }
    }
    async updateRazorpayOrderMetadata(orderId, metadata) {
        let orderData = await this.razorpay_.orders.fetch(orderId);
        if (!orderData) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Invoice with ID ${orderId} not found`);
        }
        let notes = orderData.notes;
        if (!notes) {
            notes = {
                ...metadata
            };
        }
        else {
            notes = {
                ...notes,
                ...metadata
            };
        }
        orderData = await this.razorpay_.orders.edit(orderId, {
            notes: {
                ...metadata
            }
        });
        return orderData;
    }
    async updateRazorpayMetadataInCustomer(customer, parameterName, parameterValue) {
        const metadata = customer.metadata;
        let razorpay = metadata?.razorpay;
        if (razorpay) {
            razorpay[parameterName] = parameterValue;
        }
        else {
            razorpay = {};
            razorpay[parameterName] = parameterValue;
        }
        //
        const x = await (0, update_razorpay_customer_metadata_1.updateRazorpayCustomerMetadataWorkflow)(this.container_).run({
            input: {
                medusa_customer_id: customer.id,
                razorpay
            }
        });
        const result = x.result.customer;
        return result;
    }
    async deletePayment(input) {
        try {
            return await this.cancelPayment(input);
        }
        catch (e) {
            this.logger.error(`Error deleting Razorpay payment: ${e.message}`, e);
            return {
                data: {
                    razorpayOrder: input.data?.razorpayOrder
                }
            };
        }
    }
    async getPaymentStatus(input) {
        const razorpayOrder = input.data
            ?.razorpayOrder;
        const id = razorpayOrder.id;
        let paymentIntent;
        let paymentsAttempted;
        try {
            paymentIntent = await this.razorpay_.orders.fetch(id);
            paymentsAttempted = await this.razorpay_.orders.fetchPayments(id);
        }
        catch (_e) {
            const orderId = input.data
                .order_id;
            this.logger.warn("received payment data from session not order data");
            paymentIntent = await this.razorpay_.orders.fetch(orderId);
            paymentsAttempted =
                await this.razorpay_.orders.fetchPayments(orderId);
        }
        let status = utils_1.PaymentSessionStatus.PENDING;
        switch (paymentIntent.status) {
            // created' | 'authorized' | 'captured' | 'refunded' | 'failed'
            case "created":
                status = utils_1.PaymentSessionStatus.REQUIRES_MORE;
                break;
            case "paid":
                status = utils_1.PaymentSessionStatus.AUTHORIZED;
                break;
            case "attempted":
                status = await this.getRazorpayPaymentStatus(paymentIntent, paymentsAttempted);
                break;
            default:
                status = utils_1.PaymentSessionStatus.PENDING;
        }
        return { status };
    }
    async getRazorpayPaymentStatus(paymentIntent, attempts) {
        if (!paymentIntent) {
            return utils_1.PaymentSessionStatus.ERROR;
        }
        else {
            const authorisedAttempts = attempts.items.filter((i) => i.status === utils_1.PaymentSessionStatus.AUTHORIZED);
            const totalAuthorised = authorisedAttempts.reduce((p, c) => {
                const data = p + parseInt(`${c.amount}`, 10);
                return data;
            }, 0);
            return totalAuthorised === paymentIntent.amount
                ? utils_1.PaymentSessionStatus.AUTHORIZED
                : utils_1.PaymentSessionStatus.REQUIRES_MORE;
        }
    }
    async refundPayment(input) {
        const { razorpayOrder, paymentSession } = await this.getPaymentSessionAndOrderFromInput(input);
        const id = razorpayOrder.id;
        const refundAmount = parseFloat(input.amount.toString());
        const paymentList = await this.razorpay_.orders.fetchPayments(id);
        const payment_id = paymentList.items?.find((p) => {
            return (parseInt(`${p.amount}`, 10) >= refundAmount * 100 &&
                (p.status === "authorized" || p.status === "captured"));
        })?.id;
        if (payment_id) {
            const refundRequest = {
                amount: refundAmount * 100
            };
            try {
                const razorpayRefundSession = await this.razorpay_.payments.refund(payment_id, refundRequest);
                const razorpayPayment = await this.razorpay_.payments.fetch(razorpayRefundSession.payment_id);
                const order = await this.razorpay_.orders.fetch(razorpayPayment.order_id);
                await this.syncPaymentSession(paymentSession.id, order.id);
                const refundResult = {
                    data: {
                        razorpayOrder: order,
                        razorpayRefundSession
                    }
                };
                return refundResult;
            }
            catch (e) {
                this.logger.error(`Error creating Razorpay refund: ${e.message}`, e);
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `Failed to create Razorpay refund: ${e.message}`);
            }
        }
        else {
            return {
                data: {
                    razorpayOrder: razorpayOrder
                }
            };
        }
    }
    async retrievePayment(input) {
        const { razorpayOrder } = await this.getPaymentSessionAndOrderFromInput(input);
        return {
            data: {
                razorpayOrder: razorpayOrder
            }
        };
    }
    async updatePayment(input) {
        const { razorpayOrder } = await this.getPaymentSessionAndOrderFromInput(input);
        const invoiceData = await this.updateRazorpayOrderMetadata(razorpayOrder.id, {
            ...razorpayOrder.notes,
            medusa_payment_session_id: razorpayOrder.notes
                ?.medusa_payment_session_id ??
                input?.context?.idempotency_key
        });
        return {
            data: { razorpayOrder: invoiceData }
        };
    }
    async getWebhookActionAndData(webhookData) {
        const webhookSignature = webhookData.headers["x-razorpay-signature"];
        const webhookSecret = this.options_?.webhook_secret ||
            process.env.RAZORPAY_WEBHOOK_SECRET ||
            process.env.RAZORPAY_TEST_WEBHOOK_SECRET;
        const logger = this.logger;
        const data = webhookData.data;
        logger.info(`Received Razorpay webhook body as object : ${JSON.stringify(webhookData.data)}`);
        try {
            if (!webhookSignature || !webhookSecret) {
                return { action: utils_1.PaymentActions.FAILED };
            }
            const validationResponse = razorpay_1.default.validateWebhookSignature(webhookData.rawData.toString(), webhookSignature, webhookSecret);
            // return if validation fails
            if (!validationResponse) {
                return { action: utils_1.PaymentActions.FAILED };
            }
        }
        catch (error) {
            logger.error(`Razorpay webhook validation failed : ${JSON.stringify(error)}`);
            return { action: utils_1.PaymentActions.FAILED };
        }
        const paymentData = webhookData.data
            .payload?.payment?.entity;
        const event = data.event;
        const order = await this.razorpay_.orders.fetch(paymentData.order_id);
        /** sometimes this even fires before the order is updated in the remote system */
        const outstanding = (0, get_smallest_unit_1.getAmountFromSmallestUnit)(order.amount_paid === 0 ? paymentData.amount : order.amount_paid, paymentData.currency.toUpperCase());
        switch (event) {
            // payment authorization is handled in checkout flow. webhook not needed
            case "payment.captured":
                return {
                    action: utils_1.PaymentActions.SUCCESSFUL,
                    data: {
                        session_id: paymentData.notes.session_id,
                        amount: outstanding
                    }
                };
            case "payment.authorized":
                return {
                    action: utils_1.PaymentActions.AUTHORIZED,
                    data: {
                        session_id: paymentData.notes.session_id,
                        amount: outstanding
                    }
                };
            case "payment.failed":
                return {
                    action: utils_1.PaymentActions.FAILED,
                    data: {
                        session_id: paymentData.notes.session_id,
                        amount: outstanding
                    }
                };
            default:
                return { action: utils_1.PaymentActions.NOT_SUPPORTED };
        }
    }
    async createAccountHolder(input) {
        const { first_name, last_name, email, phone, billing_address } = input
            .context.customer;
        const accountHolder = await this.razorpay_.customers.create({
            name: `${first_name} ${last_name}`,
            email: email,
            contact: phone ?? undefined,
            gstin: billing_address?.metadata?.gstin,
            notes: {
                medusa_account_holder_id: "NA"
            }
        });
        return {
            data: accountHolder,
            id: accountHolder.id
        };
    }
    async updateAccountHolder(input) {
        const { id, name, email, phone: contact } = input.data;
        const accountHolder = await this.razorpay_.customers.edit(id, {
            name: name,
            email: email,
            contact: contact
        });
        return {
            data: accountHolder
        };
    }
    async deleteAccountHolder(input) {
        const { id } = input.data;
        const accountHolder = await this.razorpay_.customers.fetch(id);
        await this.razorpay_.customers.edit(id, {
            name: "DELETED"
        });
        return {
            data: accountHolder
        };
    }
}
exports.default = RazorpayBase;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmF6b3JwYXktYmFzZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9wcm92aWRlcnMvcGF5bWVudC1yYXpvcnBheS9zcmMvY29yZS9yYXpvcnBheS1iYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBVW1DO0FBb0NuQyx3REFBZ0M7QUFVaEMsa0VBQXVFO0FBQ3ZFLHNHQUF3RztBQUV4RyxNQUFNLFlBQWEsU0FBUSwrQkFBd0M7SUFPL0QsWUFBWSxTQUEwQixFQUFFLE9BQU87UUFDM0MsS0FBSyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUUxQixJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztRQUN4QixJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxpQ0FBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFakQsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7UUFFeEIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ2hCLENBQUM7SUFFUyxJQUFJO1FBQ1YsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUMxQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxZQUFZLENBQUMsVUFBVSxDQUMxQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDckMsTUFBTSxJQUFJLG1CQUFXLENBQ2pCLHdCQUFnQixDQUFDLGdCQUFnQixFQUNqQyx5QkFBeUIsRUFDekIsd0JBQWdCLENBQUMsdUJBQXVCLENBQzNDLENBQUM7UUFDTixDQUFDO1FBQ0QsSUFBSSxDQUFDLFNBQVM7WUFDVixJQUFJLENBQUMsU0FBUztnQkFDZCxJQUFJLGtCQUFRLENBQUM7b0JBQ1QsTUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLFFBQVEsRUFBRSxPQUFPLENBQUMsTUFBTTtvQkFDeEQsVUFBVSxFQUNOLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxJQUFJLFFBQVEsRUFBRSxPQUFPLENBQUMsVUFBVTtvQkFDNUQsT0FBTyxFQUFFO3dCQUNMLGNBQWMsRUFBRSxrQkFBa0I7d0JBQ2xDLG9CQUFvQixFQUNoQixJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQjs0QkFDOUIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxnQkFBZ0I7NEJBQ2xDLFNBQVM7cUJBQ2hCO2lCQUNKLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFRCxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQXdCO1FBQzNDLElBQUksQ0FBQyxJQUFBLGlCQUFTLEVBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDN0IsTUFBTSxJQUFJLG1CQUFXLENBQ2pCLHdCQUFnQixDQUFDLGdCQUFnQixFQUNqQyx3REFBd0QsQ0FDM0QsQ0FBQztRQUNOLENBQUM7UUFDRCxJQUFJLENBQUMsSUFBQSxpQkFBUyxFQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ2pDLE1BQU0sSUFBSSxtQkFBVyxDQUNqQix3QkFBZ0IsQ0FBQyxnQkFBZ0IsRUFDakMsNERBQTRELENBQy9ELENBQUM7UUFDTixDQUFDO1FBQ0QsSUFBSSxDQUFDLElBQUEsaUJBQVMsRUFBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sSUFBSSxtQkFBVyxDQUNqQix3QkFBZ0IsQ0FBQyxnQkFBZ0IsRUFDakMsa0VBQWtFLENBQ3JFLENBQUM7UUFDTixDQUFDO1FBQ0QsSUFBSSxDQUFDLElBQUEsaUJBQVMsRUFBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsRUFBRSxDQUFDO1lBQzlDLElBQUksQ0FBQyxJQUFBLGlCQUFTLEVBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQztnQkFDM0MsTUFBTSxJQUFJLG1CQUFXLENBQ2pCLHdCQUFnQixDQUFDLGdCQUFnQixFQUNqQyxzRUFBc0UsQ0FDekUsQ0FBQztZQUNOLENBQUM7WUFDRCxNQUFNLElBQUksbUJBQVcsQ0FDakIsd0JBQWdCLENBQUMsZ0JBQWdCLEVBQ2pDLHlFQUF5RSxDQUM1RSxDQUFDO1FBQ04sQ0FBQztRQUVELElBQUksQ0FBQyxJQUFBLGlCQUFTLEVBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7WUFDckMsTUFBTSxJQUFJLG1CQUFXLENBQ2pCLHdCQUFnQixDQUFDLGdCQUFnQixFQUNqQyxnRUFBZ0UsQ0FDbkUsQ0FBQztRQUNOLENBQUM7SUFDTCxDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FDaEIsS0FBMEI7UUFFMUIsTUFBTSxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsR0FDbkMsTUFBTSxJQUFJLENBQUMsa0NBQWtDLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekQsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FDOUQsYUFBYSxDQUFDLEVBQVksQ0FDN0IsQ0FBQztRQUNGLE1BQU0sZ0JBQWdCLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FDbkQsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUN6QyxDQUFDO1FBQ0YsTUFBTSxNQUFNLEdBQUcsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNuRCxNQUFNLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDekMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDOUMsTUFBTSxlQUFlLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQ3pELEVBQUUsRUFDRixLQUFLLEVBQ0wsUUFBa0IsQ0FDckIsQ0FBQztZQUNGLE9BQU8sZUFBZSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNULE1BQU0sVUFBVSxHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUM1QyxjQUFjLENBQUMsRUFBRSxFQUNqQixhQUFhLENBQUMsRUFBWSxDQUM3QixDQUFDO1lBQ0YsTUFBTSxlQUFlLEdBQXlCO2dCQUMxQyxJQUFJLEVBQUU7b0JBQ0YsYUFBYSxFQUFFLFVBQVUsQ0FBQyxhQUFhO2lCQUMxQzthQUNKLENBQUM7WUFDRixPQUFPLGVBQWUsQ0FBQztRQUMzQixDQUFDO2FBQU0sQ0FBQztZQUNKLE1BQU0sSUFBSSxtQkFBVyxDQUNqQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLCtCQUErQixhQUFhLENBQUMsRUFBRSxFQUFFLENBQ3BELENBQUM7UUFDTixDQUFDO0lBQ0wsQ0FBQztJQUNELEtBQUssQ0FBQyxnQkFBZ0IsQ0FDbEIsS0FBNEI7UUFFNUIsTUFBTSxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsR0FDbkMsTUFBTSxJQUFJLENBQUMsa0NBQWtDLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFekQsTUFBTSxvQkFBb0IsR0FBMEI7WUFDaEQsR0FBRyxLQUFLO1NBQ1gsQ0FBQztRQUNGLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLGdCQUFnQixDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFFakUsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQ3hDLGNBQWMsQ0FBQyxFQUFFLEVBQ2pCLGFBQWEsQ0FBQyxFQUFZLENBQzdCLENBQUM7UUFFRixJQUNJLE1BQU0sQ0FBQyxNQUFNLEtBQUssNEJBQW9CLENBQUMsVUFBVTtZQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFDNUIsQ0FBQztZQUNDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsNEJBQW9CLENBQUMsUUFBUSxDQUFDO1FBQ2xELENBQUM7UUFFRCxPQUFPO1lBQ0gsSUFBSSxFQUFFO2dCQUNGLGFBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTthQUN0QztZQUNELE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtTQUN4QixDQUFDO0lBQ04sQ0FBQztJQUNELEtBQUssQ0FBQyxhQUFhLENBQ2YsS0FBeUI7UUFFekIsTUFBTSxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsR0FDbkMsTUFBTSxJQUFJLENBQUMsa0NBQWtDLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFekQsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQzNELGFBQWEsQ0FBQyxFQUFZLENBQzdCLENBQUM7UUFDRixNQUFNLGdCQUFnQixHQUFHLGFBQWEsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUNoRCxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxVQUFVLENBQ3ZDLENBQUM7UUFFRixJQUFJLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNoQyxNQUFNLElBQUksbUJBQVcsQ0FDakIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5QixnREFBZ0QsQ0FDbkQsQ0FBQztRQUNOLENBQUM7UUFFRCxNQUFNLGVBQWUsR0FBRyxhQUFhLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FDL0MsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUN6QyxDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUM1QixlQUFlLEVBQUUsR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNuQyxNQUFNLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDekMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDOUMsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO2dCQUNwRCxNQUFNLEVBQUUsS0FBSztnQkFDYixLQUFLLEVBQUU7b0JBQ0gseUJBQXlCLEVBQUUsY0FBYyxDQUFDLEVBQUU7aUJBQy9DO2FBQ0osQ0FBQyxDQUFDO1lBQ0gsT0FBTyxNQUFNLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQ0wsQ0FBQztRQUNGLE1BQU0sVUFBVSxHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUM1QyxjQUFjLENBQUMsRUFBRSxFQUNqQixhQUFhLENBQUMsRUFBWSxDQUM3QixDQUFDO1FBRUYsT0FBTztZQUNILElBQUksRUFBRTtnQkFDRixhQUFhLEVBQUUsVUFBVSxDQUFDLGFBQWE7Z0JBQ3ZDLGVBQWUsRUFBRSxNQUFNO2FBQzFCO1NBQ0osQ0FBQztJQUNOLENBQUM7SUFFRCxLQUFLLENBQUMsa0NBQWtDLENBQ3BDLEtBT3dCO1FBS3hCLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLEdBQUcsS0FBSyxDQUFDO1FBQzlCLElBQUksQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLENBQUM7WUFDdkIsSUFBSSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUM7Z0JBQ1gsSUFBSSxHQUFHO29CQUNILEdBQUcsSUFBSTtvQkFDUCxhQUFhLEVBQUUsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQzVDLElBQUksQ0FBQyxFQUFZLENBQ3BCO2lCQUNKLENBQUM7WUFDTixDQUFDO1FBQ0wsQ0FBQztRQUNELElBQUksRUFBRSxhQUFhLEVBQUUsR0FBRyxJQUErQyxDQUFDO1FBRXhFLE1BQU0sZ0JBQWdCLEdBQ2pCLGFBQWEsRUFBRSxLQUFnQztZQUM1QyxFQUFFLHlCQUF5QixJQUFJLE9BQU8sRUFBRSxlQUFlLENBQUM7UUFFaEUsTUFBTSxjQUFjLEdBQ2hCLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNqQixhQUFhLEdBQUcsY0FBYyxFQUFFLElBQUk7Z0JBQ2hDLEVBQUUsYUFBcUMsQ0FBQztRQUNoRCxDQUFDO1FBQ0QsSUFBSSxhQUFhLEVBQUUsQ0FBQztZQUNoQixNQUFNLG9CQUFvQixHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUMxRCxhQUFhLENBQUMsRUFBWSxDQUM3QixDQUFDO1lBRUYsSUFBSSxvQkFBb0IsQ0FBQyxNQUFNLEtBQUssYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUN2RCxhQUFhLEdBQUcsb0JBQW9CLENBQUM7WUFDekMsQ0FBQztRQUNMLENBQUM7UUFFRCxPQUFPO1lBQ0gsY0FBYztZQUNkLGFBQWEsRUFBRSxhQUFhO1NBQy9CLENBQUM7SUFDTixDQUFDO0lBRU8saUNBQWlDLENBQ3JDLE1BQWMsRUFDZCxhQUFxQjtRQUVyQixNQUFNLGFBQWEsR0FBMEM7WUFDekQsTUFBTSxFQUFFLE1BQU07WUFDZCxRQUFRLEVBQUUsYUFBYSxDQUFDLFdBQVcsRUFBRTtZQUVyQyxPQUFPLEVBQUU7Z0JBQ0wsT0FBTyxFQUNILENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDO29CQUNoQyxDQUFDLENBQUMsV0FBVztvQkFDYixDQUFDLENBQUMsUUFBUTtnQkFDbEIsZUFBZSxFQUFFO29CQUNiLFlBQVksRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksSUFBSSxRQUFRO29CQUNwRCx1QkFBdUIsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUM3QixJQUFJLENBQUMsUUFBUSxDQUFDLHVCQUF1QixJQUFJLEVBQUUsRUFDM0MsRUFBRSxDQUNMO29CQUNELG9CQUFvQixFQUFFLElBQUksQ0FBQyxHQUFHLENBQzFCLElBQUksQ0FBQyxRQUFRLENBQUMsb0JBQW9CLElBQUksRUFBRSxFQUN4QyxJQUFJLENBQ1A7aUJBQ0o7YUFDSjtTQUNKLENBQUM7UUFDRixPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsS0FBSyxDQUFDLGtCQUFrQixDQUNwQixnQkFBd0IsRUFDeEIsZUFBdUI7UUFLdkIsTUFBTSxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUMsMkJBQTJCLENBQ3BELGVBQWUsRUFDZjtZQUNJLHlCQUF5QixFQUFFLGdCQUFnQjtTQUM5QyxDQUNKLENBQUM7UUFDRixNQUFNLGtCQUFrQixHQUNwQixNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN2RSxPQUFPO1lBQ0gsYUFBYSxFQUFFLFNBQVM7WUFDeEIsY0FBYyxFQUFFLGtCQUFrQjtTQUNyQyxDQUFDO0lBQ04sQ0FBQztJQUdELFFBQVEsQ0FBRSxNQUFzQixFQUFFLGFBQXFCO1FBQ25ELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFBLDZDQUF5QixFQUN2QyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFDM0MsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUM5QixHQUFHLEdBQUcsR0FBQyxHQUFHLENBQUMsQ0FBQztJQUNqQixDQUFDO0lBRUQsS0FBSyxDQUFDLGVBQWUsQ0FDakIsS0FBMkI7UUFFM0IsTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQztRQUV4RCxNQUFNLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxHQUFHLEtBQUssQ0FBQztRQUV4QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUM7WUFDRCxNQUFNLDBCQUEwQixHQUM1QixJQUFJLENBQUMsaUNBQWlDLENBQUMsS0FBSyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBRWpFLE1BQU0sYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUNwRCwwQkFBMEIsQ0FDN0IsQ0FBQztZQUVGLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUNwQixNQUFNLElBQUksbUJBQVcsQ0FDakIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5QixnQ0FBZ0MsQ0FDbkMsQ0FBQztZQUNOLENBQUM7WUFDRCxPQUFPO2dCQUNILEVBQUUsRUFBRSxnQkFBZ0I7Z0JBQ3BCLElBQUksRUFBRSxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUU7YUFDekMsQ0FBQztRQUNOLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQ2Isa0NBQWtDLEtBQUssQ0FBQyxPQUFPLEVBQUUsRUFDakQsS0FBSyxDQUNSLENBQUM7WUFDRixNQUFNLElBQUksbUJBQVcsQ0FDakIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5QixvQ0FBb0MsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUN0RCxDQUFDO1FBQ04sQ0FBQztJQUNMLENBQUM7SUFDRCxLQUFLLENBQUMsMkJBQTJCLENBQzdCLE9BQWUsRUFDZixRQUErQjtRQUUvQixJQUFJLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDYixNQUFNLElBQUksbUJBQVcsQ0FDakIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUMzQixtQkFBbUIsT0FBTyxZQUFZLENBQ3pDLENBQUM7UUFDTixDQUFDO1FBQ0QsSUFBSSxLQUFLLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQztRQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDVCxLQUFLLEdBQUc7Z0JBQ0osR0FBRyxRQUFRO2FBQ2QsQ0FBQztRQUNOLENBQUM7YUFBTSxDQUFDO1lBQ0osS0FBSyxHQUFHO2dCQUNKLEdBQUcsS0FBSztnQkFDUixHQUFHLFFBQVE7YUFDZCxDQUFDO1FBQ04sQ0FBQztRQUVELFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDbEQsS0FBSyxFQUFFO2dCQUNILEdBQUcsUUFBUTthQUNkO1NBQ0osQ0FBQyxDQUFDO1FBQ0gsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUNELEtBQUssQ0FBQyxnQ0FBZ0MsQ0FDbEMsUUFBcUIsRUFDckIsYUFBcUIsRUFDckIsY0FBc0I7UUFFdEIsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQztRQUNuQyxJQUFJLFFBQVEsR0FBRyxRQUFRLEVBQUUsUUFBa0MsQ0FBQztRQUM1RCxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ1gsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLGNBQWMsQ0FBQztRQUM3QyxDQUFDO2FBQU0sQ0FBQztZQUNKLFFBQVEsR0FBRyxFQUFFLENBQUM7WUFDZCxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsY0FBYyxDQUFDO1FBQzdDLENBQUM7UUFDRCxFQUFFO1FBQ0YsTUFBTSxDQUFDLEdBQUcsTUFBTSxJQUFBLDBFQUFzQyxFQUNsRCxJQUFJLENBQUMsVUFBVSxDQUNsQixDQUFDLEdBQUcsQ0FBQztZQUNGLEtBQUssRUFBRTtnQkFDSCxrQkFBa0IsRUFBRSxRQUFRLENBQUMsRUFBRTtnQkFDL0IsUUFBUTthQUNYO1NBQ0osQ0FBQyxDQUFDO1FBQ0gsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFFakMsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQ2YsS0FBeUI7UUFFekIsSUFBSSxDQUFDO1lBQ0QsT0FBTyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0MsQ0FBQztRQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDVCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FDYixvQ0FBb0MsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUMvQyxDQUFDLENBQ0osQ0FBQztZQUNGLE9BQU87Z0JBQ0gsSUFBSSxFQUFFO29CQUNGLGFBQWEsRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLGFBQWE7aUJBQzNDO2FBQ0osQ0FBQztRQUNOLENBQUM7SUFDTCxDQUFDO0lBQ0QsS0FBSyxDQUFDLGdCQUFnQixDQUNsQixLQUE0QjtRQUU1QixNQUFNLGFBQWEsR0FBRyxLQUFLLENBQUMsSUFBSTtZQUM1QixFQUFFLGFBQWdELENBQUM7UUFDdkQsTUFBTSxFQUFFLEdBQUcsYUFBYSxDQUFDLEVBQVksQ0FBQztRQUV0QyxJQUFJLGFBQW1DLENBQUM7UUFDeEMsSUFBSSxpQkFJSCxDQUFDO1FBQ0YsSUFBSSxDQUFDO1lBQ0QsYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RELGlCQUFpQixHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7UUFBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO1lBQ1YsTUFBTSxPQUFPLEdBQUksS0FBSyxDQUFDLElBQTRDO2lCQUM5RCxRQUFrQixDQUFDO1lBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUNaLG1EQUFtRCxDQUN0RCxDQUFDO1lBQ0YsYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzNELGlCQUFpQjtnQkFDYixNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzRCxDQUFDO1FBQ0QsSUFBSSxNQUFNLEdBQXlCLDRCQUFvQixDQUFDLE9BQU8sQ0FBQztRQUNoRSxRQUFRLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUMzQiwrREFBK0Q7WUFDL0QsS0FBSyxTQUFTO2dCQUNWLE1BQU0sR0FBRyw0QkFBb0IsQ0FBQyxhQUFhLENBQUM7Z0JBQzVDLE1BQU07WUFDVixLQUFLLE1BQU07Z0JBQ1AsTUFBTSxHQUFHLDRCQUFvQixDQUFDLFVBQVUsQ0FBQztnQkFDekMsTUFBTTtZQUVWLEtBQUssV0FBVztnQkFDWixNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsd0JBQXdCLENBQ3hDLGFBQWEsRUFDYixpQkFBaUIsQ0FDcEIsQ0FBQztnQkFDRixNQUFNO1lBQ1Y7Z0JBQ0ksTUFBTSxHQUFHLDRCQUFvQixDQUFDLE9BQU8sQ0FBQztRQUM5QyxDQUFDO1FBQ0QsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFDRCxLQUFLLENBQUMsd0JBQXdCLENBQzFCLGFBQW1DLEVBQ25DLFFBSUM7UUFFRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDakIsT0FBTyw0QkFBb0IsQ0FBQyxLQUFLLENBQUM7UUFDdEMsQ0FBQzthQUFNLENBQUM7WUFDSixNQUFNLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUM1QyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyw0QkFBb0IsQ0FBQyxVQUFVLENBQ3RELENBQUM7WUFDRixNQUFNLGVBQWUsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELE1BQU0sSUFBSSxHQUFHLENBQUMsR0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzNDLE9BQU8sSUFBSSxDQUFDO1lBQ2hCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNOLE9BQU8sZUFBZSxLQUFLLGFBQWEsQ0FBQyxNQUFNO2dCQUMzQyxDQUFDLENBQUMsNEJBQW9CLENBQUMsVUFBVTtnQkFDakMsQ0FBQyxDQUFDLDRCQUFvQixDQUFDLGFBQWEsQ0FBQztRQUM3QyxDQUFDO0lBQ0wsQ0FBQztJQUNELEtBQUssQ0FBQyxhQUFhLENBQ2YsS0FBeUI7UUFFekIsTUFBTSxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsR0FDbkMsTUFBTSxJQUFJLENBQUMsa0NBQWtDLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekQsTUFBTSxFQUFFLEdBQUcsYUFBYSxDQUFDLEVBQVksQ0FBQztRQUN0QyxNQUFNLFlBQVksR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sV0FBVyxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRWxFLE1BQU0sVUFBVSxHQUFHLFdBQVcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDN0MsT0FBTyxDQUNILFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLENBQUMsSUFBSSxZQUFZLEdBQUcsR0FBRztnQkFDakQsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLFlBQVksSUFBSSxDQUFDLENBQUMsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUN6RCxDQUFDO1FBQ04sQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ1AsSUFBSSxVQUFVLEVBQUUsQ0FBQztZQUNiLE1BQU0sYUFBYSxHQUFHO2dCQUNsQixNQUFNLEVBQUUsWUFBWSxHQUFHLEdBQUc7YUFDN0IsQ0FBQztZQUNGLElBQUksQ0FBQztnQkFDRCxNQUFNLHFCQUFxQixHQUN2QixNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDaEMsVUFBVSxFQUNWLGFBQWEsQ0FDaEIsQ0FBQztnQkFDTixNQUFNLGVBQWUsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FDdkQscUJBQXFCLENBQUMsVUFBVSxDQUNuQyxDQUFDO2dCQUNGLE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUMzQyxlQUFlLENBQUMsUUFBUSxDQUMzQixDQUFDO2dCQUVGLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUN6QixjQUFjLENBQUMsRUFBRSxFQUNqQixLQUFLLENBQUMsRUFBWSxDQUNyQixDQUFDO2dCQUVGLE1BQU0sWUFBWSxHQUF3QjtvQkFDdEMsSUFBSSxFQUFFO3dCQUNGLGFBQWEsRUFBRSxLQUFLO3dCQUNwQixxQkFBcUI7cUJBQ3hCO2lCQUNKLENBQUM7Z0JBQ0YsT0FBTyxZQUFZLENBQUM7WUFDeEIsQ0FBQztZQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ1QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQ2IsbUNBQW1DLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFDOUMsQ0FBQyxDQUNKLENBQUM7Z0JBQ0YsTUFBTSxJQUFJLG1CQUFXLENBQ2pCLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIscUNBQXFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FDbkQsQ0FBQztZQUNOLENBQUM7UUFDTCxDQUFDO2FBQU0sQ0FBQztZQUNKLE9BQU87Z0JBQ0gsSUFBSSxFQUFFO29CQUNGLGFBQWEsRUFBRSxhQUFhO2lCQUMvQjthQUNKLENBQUM7UUFDTixDQUFDO0lBQ0wsQ0FBQztJQUNELEtBQUssQ0FBQyxlQUFlLENBQ2pCLEtBQTJCO1FBRTNCLE1BQU0sRUFBRSxhQUFhLEVBQUUsR0FDbkIsTUFBTSxJQUFJLENBQUMsa0NBQWtDLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFekQsT0FBTztZQUNILElBQUksRUFBRTtnQkFDRixhQUFhLEVBQUUsYUFBYTthQUMvQjtTQUNKLENBQUM7SUFDTixDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FDZixLQUF5QjtRQUV6QixNQUFNLEVBQUUsYUFBYSxFQUFFLEdBQ25CLE1BQU0sSUFBSSxDQUFDLGtDQUFrQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pELE1BQU0sV0FBVyxHQUFHLE1BQU0sSUFBSSxDQUFDLDJCQUEyQixDQUN0RCxhQUFhLENBQUMsRUFBWSxFQUUxQjtZQUNJLEdBQUcsYUFBYSxDQUFDLEtBQUs7WUFDdEIseUJBQXlCLEVBQ25CLGFBQWEsQ0FBQyxLQUFpQztnQkFDN0MsRUFBRSx5QkFBb0M7Z0JBQzFDLEtBQUssRUFBRSxPQUFPLEVBQUUsZUFBZTtTQUN0QyxDQUNKLENBQUM7UUFDRixPQUFPO1lBQ0gsSUFBSSxFQUFFLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRTtTQUN2QyxDQUFDO0lBQ04sQ0FBQztJQUNELEtBQUssQ0FBQyx1QkFBdUIsQ0FDekIsV0FBOEM7UUFFOUMsTUFBTSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFFckUsTUFBTSxhQUFhLEdBQ2YsSUFBSSxDQUFDLFFBQVEsRUFBRSxjQUFjO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCO1lBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLENBQUM7UUFFN0MsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMzQixNQUFNLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDO1FBRTlCLE1BQU0sQ0FBQyxJQUFJLENBQ1AsOENBQThDLElBQUksQ0FBQyxTQUFTLENBQ3hELFdBQVcsQ0FBQyxJQUFJLENBQ25CLEVBQUUsQ0FDTixDQUFDO1FBQ0YsSUFBSSxDQUFDO1lBQ0QsSUFBSSxDQUFDLGdCQUFnQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3RDLE9BQU8sRUFBRSxNQUFNLEVBQUUsc0JBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM3QyxDQUFDO1lBQ0QsTUFBTSxrQkFBa0IsR0FBRyxrQkFBUSxDQUFDLHdCQUF3QixDQUN4RCxXQUFXLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUM5QixnQkFBMEIsRUFDMUIsYUFBYSxDQUNoQixDQUFDO1lBQ0YsNkJBQTZCO1lBQzdCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUN0QixPQUFPLEVBQUUsTUFBTSxFQUFFLHNCQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDN0MsQ0FBQztRQUNMLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2IsTUFBTSxDQUFDLEtBQUssQ0FDUix3Q0FBd0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUNsRSxDQUFDO1lBRUYsT0FBTyxFQUFFLE1BQU0sRUFBRSxzQkFBYyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzdDLENBQUM7UUFDRCxNQUFNLFdBQVcsR0FBSSxXQUFXLENBQUMsSUFBb0M7YUFDaEUsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUM7UUFDOUIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUV6QixNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEUsaUZBQWlGO1FBQ2pGLE1BQU0sV0FBVyxHQUFHLElBQUEsNkNBQXlCLEVBQ3pDLEtBQUssQ0FBQyxXQUFXLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUNoRSxXQUFXLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUNyQyxDQUFDO1FBRUYsUUFBUSxLQUFLLEVBQUUsQ0FBQztZQUNaLHdFQUF3RTtZQUV4RSxLQUFLLGtCQUFrQjtnQkFDbkIsT0FBTztvQkFDSCxNQUFNLEVBQUUsc0JBQWMsQ0FBQyxVQUFVO29CQUNqQyxJQUFJLEVBQUU7d0JBQ0YsVUFBVSxFQUNOLFdBQVcsQ0FBQyxLQUlmLENBQUMsVUFBb0I7d0JBQ3RCLE1BQU0sRUFBRSxXQUFXO3FCQUN0QjtpQkFDSixDQUFDO1lBRU4sS0FBSyxvQkFBb0I7Z0JBQ3JCLE9BQU87b0JBQ0gsTUFBTSxFQUFFLHNCQUFjLENBQUMsVUFBVTtvQkFDakMsSUFBSSxFQUFFO3dCQUNGLFVBQVUsRUFDTixXQUFXLENBQUMsS0FJZixDQUFDLFVBQW9CO3dCQUN0QixNQUFNLEVBQUUsV0FBVztxQkFDdEI7aUJBQ0osQ0FBQztZQUVOLEtBQUssZ0JBQWdCO2dCQUNqQixPQUFPO29CQUNILE1BQU0sRUFBRSxzQkFBYyxDQUFDLE1BQU07b0JBQzdCLElBQUksRUFBRTt3QkFDRixVQUFVLEVBQ04sV0FBVyxDQUFDLEtBSWYsQ0FBQyxVQUFvQjt3QkFDdEIsTUFBTSxFQUFFLFdBQVc7cUJBQ3RCO2lCQUNKLENBQUM7WUFFTjtnQkFDSSxPQUFPLEVBQUUsTUFBTSxFQUFFLHNCQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDeEQsQ0FBQztJQUNMLENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQ3JCLEtBQStCO1FBRS9CLE1BQU0sRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLEdBQUcsS0FBSzthQUNqRSxPQUFPLENBQUMsUUFBOEIsQ0FBQztRQUM1QyxNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztZQUN4RCxJQUFJLEVBQUUsR0FBRyxVQUFVLElBQUksU0FBUyxFQUFFO1lBQ2xDLEtBQUssRUFBRSxLQUFLO1lBQ1osT0FBTyxFQUFFLEtBQUssSUFBSSxTQUFTO1lBQzNCLEtBQUssRUFBRSxlQUFlLEVBQUUsUUFBUSxFQUFFLEtBQWU7WUFDakQsS0FBSyxFQUFFO2dCQUNILHdCQUF3QixFQUFFLElBQUk7YUFDakM7U0FDSixDQUFDLENBQUM7UUFFSCxPQUFPO1lBQ0gsSUFBSSxFQUFFLGFBQW1EO1lBQ3pELEVBQUUsRUFBRSxhQUFhLENBQUMsRUFBRTtTQUN2QixDQUFDO0lBQ04sQ0FBQztJQUNELEtBQUssQ0FBQyxtQkFBbUIsQ0FDckIsS0FBK0I7UUFFL0IsTUFBTSxFQUNGLEVBQUUsRUFDRixJQUFJLEVBQ0osS0FBSyxFQUNMLEtBQUssRUFBRSxPQUFPLEVBQ2pCLEdBQUcsS0FBSyxDQUFDLElBTVQsQ0FBQztRQUNGLE1BQU0sYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUMxRCxJQUFJLEVBQUUsSUFBSTtZQUNWLEtBQUssRUFBRSxLQUFLO1lBQ1osT0FBTyxFQUFFLE9BQU87U0FDbkIsQ0FBQyxDQUFDO1FBQ0gsT0FBTztZQUNILElBQUksRUFBRSxhQUFtRDtTQUM1RCxDQUFDO0lBQ04sQ0FBQztJQUNELEtBQUssQ0FBQyxtQkFBbUIsQ0FDckIsS0FBK0I7UUFFL0IsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFzQixDQUFDO1FBQzVDLE1BQU0sYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQy9ELE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNwQyxJQUFJLEVBQUUsU0FBUztTQUNsQixDQUFDLENBQUM7UUFDSCxPQUFPO1lBQ0gsSUFBSSxFQUFFLGFBQW1EO1NBQzVELENBQUM7SUFDTixDQUFDO0NBQ0o7QUFFRCxrQkFBZSxZQUFZLENBQUMifQ==